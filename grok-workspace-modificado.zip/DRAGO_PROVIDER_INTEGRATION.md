# DRAGO ↔ Grok provider integration

This workspace exposes an OpenAI-compatible API for a DRAGO desktop client.

## Endpoint

`https://<your-provider-host>/api/v1`

### Models

`GET /models` lists the public aliases.

`POST /chat/completions` accepts OpenAI-style `model` and `messages`.
`lumen-vision` accepts OpenAI-style text/image content parts when the configured upstream model supports vision.

## DRAGO configuration

Set these client-side values in DRAGO:

- `OnlineBaseUrl`: `https://<your-provider-host>/api/v1`
- `OnlineApiKey`: the `sk-lx-...` key issued by this server
- `OnlineModel`: `lumen-max` (or another model returned by `/models`)

Do **not** put `XAI_API_KEY` or `XAI_SIGNING_SECRET` in DRAGO. Those are server secrets.

## Server configuration

Copy `.env.example` to the deployment environment and set:

- `XAI_API_KEY`: the real xAI credential
- `XAI_SIGNING_SECRET`: a separate random secret used to sign DRAGO keys
- `XAI_MODEL_*`: real upstream model IDs available to that xAI account

The proxy now propagates provider failures instead of returning a fake successful answer for HTTP 402/403. A DRAGO client can therefore retry, switch providers, or show a useful error.

## Important

The `sk-lx-*` key is only a credential for this proxy. It does not create free xAI usage, bypass account restrictions, age checks, billing, or provider quotas. Those remain controlled by the upstream provider/account.
