const base = (process.env.PROVIDER_BASE_URL || "http://localhost:8080/api/v1").replace(/\/$/, "");
const key = process.env.PROVIDER_API_KEY;
if (!key) throw new Error("Set PROVIDER_API_KEY to an sk-lx-* key before running this test.");

const models = await fetch(`${base}/models`);
if (!models.ok) throw new Error(`GET /models failed: ${models.status}`);
console.log("models: OK");

const chat = await fetch(`${base}/chat/completions`, {
  method: "POST",
  headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
  body: JSON.stringify({
    model: process.env.PROVIDER_MODEL || "lumen-flash",
    messages: [{ role: "user", content: "Responda apenas: OK" }],
  }),
});
const body = await chat.json();
if (!chat.ok) throw new Error(`POST /chat/completions failed: ${chat.status} ${JSON.stringify(body)}`);
console.log("chat: OK", body.choices?.[0]?.message?.content ?? "");
