import{b as e,d as t,h as n,i as r,l as i,n as a,t as o,u as s,y as c}from"./panel-DbomCso1.js";import{n as l,t as u}from"./use-origin-DpHxKKdL.js";import{_ as d,m as f,n as p,r as m,s as h}from"./index-Cr8atpKD.js";var g=p(`check`,[[`path`,{d:`M20 6 9 17l-5-5`,key:`1gmf2c`}]]),_=d(f(),1),v=h();function y({code:t,label:r}){let[i,a]=(0,_.useState)(!1);return(0,v.jsxs)(`div`,{className:`overflow-hidden rounded-lg bg-code shadow-[var(--shadow-border)]`,children:[(0,v.jsxs)(`div`,{className:`flex items-center justify-between border-b border-border px-3 py-1.5`,children:[(0,v.jsx)(`span`,{className:`text-xs text-subtle`,children:r}),(0,v.jsx)(n,{variant:`ghost`,size:`iconSm`,"aria-label":`Copy`,onClick:async()=>{await e(t),a(!0),setTimeout(()=>a(!1),1500)},children:i?(0,v.jsx)(g,{}):(0,v.jsx)(l,{})})]}),(0,v.jsx)(`pre`,{className:c(`overflow-x-auto p-4 font-mono text-xs leading-6 text-fg`),children:(0,v.jsx)(`code`,{children:t})})]})}function b(){let e=r(e=>e.locale),l=r(e=>e.regionId),d=t(e),f=u(),p=f?i(f):`https://<host>/api/v1`,[h,g]=(0,_.useState)(`curl`),b=`curl ${p}/chat/completions \\
  -H "Authorization: Bearer $LUMEN_API_KEY" \\
  -H "Content-Type: application/json" \\
  -d '{
    "model": "lumen-max",
    "messages": [{"role":"user","content":"Olá"}]
  }'`,x=`from openai import OpenAI

client = OpenAI(
    api_key="sk-lx-...",
    base_url="${p}",
)

r = client.chat.completions.create(
    model="lumen-max",
    messages=[{"role": "user", "content": "Olá"}],
)
print(r.choices[0].message.content)`,S=`import OpenAI from "openai";

const client = new OpenAI({
  apiKey: process.env.LUMEN_API_KEY,
  baseURL: "${p}",
});

const r = await client.chat.completions.create({
  model: "lumen-max",
  messages: [{ role: "user", content: "Olá" }],
});
console.log(r.choices[0].message.content);`,C=h===`curl`?b:h===`py`?x:S;return(0,v.jsxs)(a,{title:d.docsTitle,hint:d.docsHint,children:[(0,v.jsxs)(`div`,{className:`grid gap-4 lg:grid-cols-3`,children:[(0,v.jsxs)(o,{className:`p-5`,children:[(0,v.jsx)(`p`,{className:`text-xs font-medium text-subtle`,children:d.step1}),(0,v.jsx)(`p`,{className:`mt-2 text-sm leading-6 text-muted`,children:d.emptyBody}),(0,v.jsx)(n,{asChild:!0,className:`mt-4`,size:`sm`,children:(0,v.jsx)(m,{to:`/`,children:d.goCreate})})]}),(0,v.jsxs)(o,{className:`p-5`,children:[(0,v.jsx)(`p`,{className:`text-xs font-medium text-subtle`,children:d.step2}),(0,v.jsx)(`p`,{className:`mt-2 font-mono text-xs break-all`,children:p}),(0,v.jsx)(`p`,{className:`mt-2 text-xs text-subtle`,children:s(l,e)})]}),(0,v.jsxs)(o,{className:`p-5`,children:[(0,v.jsx)(`p`,{className:`text-xs font-medium text-subtle`,children:d.step3}),(0,v.jsx)(`p`,{className:`mt-2 text-sm leading-6 text-muted`,children:d.allRegions})]})]}),(0,v.jsx)(`div`,{className:`mt-6 flex gap-1`,children:[[`curl`,d.exampleCurl],[`py`,d.examplePy],[`js`,d.exampleJs]].map(([e,t])=>(0,v.jsx)(`button`,{type:`button`,onClick:()=>g(e),className:c(`h-10 rounded-md px-3 text-sm`,h===e?`bg-primary-soft font-medium text-primary`:`text-muted hover:text-fg`),children:t},e))}),(0,v.jsx)(`div`,{className:`mt-3`,children:(0,v.jsx)(y,{code:C,label:h===`curl`?d.exampleCurl:h===`py`?d.examplePy:d.exampleJs})})]})}export{b as component};