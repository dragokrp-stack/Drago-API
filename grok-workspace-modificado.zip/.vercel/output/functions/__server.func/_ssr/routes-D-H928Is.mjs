import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as createServerFn } from "./ssr.mjs";
import { o as apiHost, r as MODELS } from "./models-CJww7k-s.mjs";
import { _ as Copy, c as Pencil, d as KeyRound, g as Download, h as Ellipsis, r as Trash2, s as Plus } from "../_libs/lucide-react.mjs";
import { _ as useStudio, a as NativeSelect, c as cn, d as formatDate, g as useHydrated, h as t, i as Input, l as copyText, m as parseIpList, n as Button, o as Panel, p as maskKey, r as ConsoleShell, s as Textarea, t as Badge, u as downloadText, v as useVisibleKeys } from "./panel-Bkw87EqF.mjs";
import { t as useOrigin } from "./use-origin-BHbgPkVo.mjs";
import { t as createSsrRpc } from "./createSsrRpc-C1p7zOu_.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as DialogContent, t as Dialog } from "./dialog-CTCHyOEH.mjs";
import { a as Trigger, i as Root2, n as Item2, r as Portal2, t as Content2 } from "../_libs/@radix-ui/react-dropdown-menu+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-D-H928Is.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var DropdownMenu = Root2;
var DropdownMenuTrigger = Trigger;
function DropdownMenuContent({ className, children, align = "end" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal2, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
		align,
		sideOffset: 6,
		className: cn("z-50 min-w-40 rounded-lg bg-surface p-1 shadow-[var(--shadow-modal)]", "data-[state=open]:animate-[fade-in_var(--motion-fast)_var(--ease-out)]", className),
		children
	}) });
}
function DropdownMenuItem({ className, tone = "default", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item2, {
		className: cn("flex h-9 cursor-pointer items-center gap-2 rounded-md px-2.5 text-sm outline-none", "data-highlighted:bg-bg", tone === "danger" ? "text-danger" : "text-fg", className),
		...props
	});
}
var issueApiKey = createServerFn({ method: "POST" }).handler(createSsrRpc("8a394adfbd1c1cbbab4854500a44c6954e094b5fcc62cd97146f20a2f1cb1d90"));
var emptyForm = (workspaceId) => ({
	workspaceId,
	description: "",
	access: "all",
	ipWhitelist: "0.0.0.0/0",
	allowedModels: MODELS.filter((m) => m.chat).map((m) => m.id)
});
function KeysManager() {
	const locale = useStudio((s) => s.locale);
	const copy = t(locale);
	const regionId = useStudio((s) => s.regionId);
	const workspaces = useStudio((s) => s.workspaces);
	const query = useStudio((s) => s.query);
	const hydrated = useHydrated();
	const [tab, setTab] = (0, import_react.useState)("standard");
	const keys = useVisibleKeys(tab);
	const [createOpen, setCreateOpen] = (0, import_react.useState)(false);
	const [form, setForm] = (0, import_react.useState)(emptyForm("ws-default"));
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [reveal, setReveal] = (0, import_react.useState)(null);
	const [edit, setEdit] = (0, import_react.useState)(null);
	const [confirm, setConfirm] = (0, import_react.useState)(null);
	const origin = useOrigin();
	const host = origin ? apiHost(origin) : "";
	function openCreate() {
		setForm(emptyForm(workspaces[0]?.id ?? "ws-default"));
		setCreateOpen(true);
	}
	async function submitCreate() {
		setBusy(true);
		try {
			const issued = await issueApiKey();
			const rec = {
				id: issued.id,
				secret: issued.key,
				kind: tab,
				description: form.description.trim().slice(0, 200),
				workspaceId: form.workspaceId,
				regionId,
				status: "enabled",
				access: form.access,
				ipWhitelist: form.access === "custom" ? parseIpList(form.ipWhitelist).join(", ") || "0.0.0.0/0" : "0.0.0.0/0",
				allowedModels: form.access === "custom" ? form.allowedModels : [],
				createdAt: issued.issuedAt,
				expiresAt: tab === "temporary" ? issued.issuedAt + 864e5 : null,
				lastUsedAt: null
			};
			if (!useStudio.getState().addKey(rec).ok) {
				toast.error(copy.limit);
				return;
			}
			setCreateOpen(false);
			setReveal(rec);
		} catch {
			toast.error(copy.errIssue);
		} finally {
			setBusy(false);
		}
	}
	async function submitReset(key) {
		setBusy(true);
		try {
			const issued = await issueApiKey();
			const next = {
				...key,
				id: issued.id,
				secret: issued.key,
				createdAt: issued.issuedAt,
				expiresAt: key.kind === "temporary" ? issued.issuedAt + 864e5 : key.expiresAt,
				lastUsedAt: null
			};
			useStudio.getState().removeKey(key.id);
			if (!useStudio.getState().addKey(next).ok) {
				useStudio.getState().addKey(key);
				toast.error(copy.limit);
				return;
			}
			setConfirm(null);
			setReveal(next);
		} catch {
			toast.error(copy.errIssue);
		} finally {
			setBusy(false);
		}
	}
	function saveEdit() {
		if (!edit) return;
		useStudio.getState().updateKey(edit.id, {
			description: form.description.trim().slice(0, 200),
			workspaceId: form.workspaceId,
			access: form.access,
			ipWhitelist: form.access === "custom" ? parseIpList(form.ipWhitelist).join(", ") || "0.0.0.0/0" : "0.0.0.0/0",
			allowedModels: form.access === "custom" ? form.allowedModels : []
		});
		setEdit(null);
	}
	async function onCopy(secret) {
		await copyText(secret);
		toast.success(copy.copied);
	}
	const filteredEmpty = hydrated && keys.length === 0 && query.trim().length > 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-3 rounded-lg bg-primary-soft px-4 py-3 text-sm text-fg",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-0.5 inline-block size-2 shrink-0 rounded-full bg-success" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: copy.banner })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-1 border-b border-border",
					children: ["standard", "temporary"].map((kind) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setTab(kind),
						className: cn("-mb-px h-11 px-3 text-sm transition-colors duration-(--motion-quick)", tab === kind ? "border-b-2 border-primary font-medium text-primary" : "text-muted hover:text-fg"),
						children: kind === "standard" ? copy.tabStandard : copy.tabTemp
					}, kind))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "lg",
					onClick: openCreate,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), tab === "standard" ? copy.createKey : copy.createTemp]
				})]
			}),
			!hydrated ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				className: "space-y-2 p-4",
				children: Array.from({ length: 4 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-12 animate-pulse rounded-md bg-bg" }, i))
			}) : keys.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "flex flex-col items-center px-6 py-14 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mb-3 inline-flex size-12 items-center justify-center rounded-xl bg-primary-soft text-primary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, { className: "size-6" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-base font-semibold",
						children: filteredEmpty ? copy.noMatch : copy.emptyTitle
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 max-w-md text-sm text-muted",
						children: filteredEmpty ? copy.filter : copy.emptyBody
					}),
					!filteredEmpty ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						className: "mt-5",
						onClick: openCreate,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), tab === "standard" ? copy.createKey : copy.createTemp]
					}) : null
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "hidden overflow-x-auto md:block",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-left text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b border-border text-xs text-subtle",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: copy.colKey
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: copy.colDesc
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: copy.colWorkspace
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: copy.colCreated
							}),
							tab === "temporary" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: copy.colExpires
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: copy.lastUsed
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: copy.colStatus
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: copy.colActions
							})
						]
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: keys.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRow, {
						rec: k,
						locale,
						onCopy: () => onCopy(k.secret),
						onEdit: () => {
							setForm({
								workspaceId: k.workspaceId,
								description: k.description,
								access: k.access,
								ipWhitelist: k.ipWhitelist || "0.0.0.0/0",
								allowedModels: k.allowedModels.length > 0 ? k.allowedModels : MODELS.filter((m) => m.chat).map((m) => m.id)
							});
							setEdit(k);
						},
						onDelete: () => setConfirm({
							type: "delete",
							key: k
						}),
						onReset: () => setConfirm({
							type: "reset",
							key: k
						})
					}, k.id)) })]
				}) })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-3 md:hidden",
				children: keys.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyCard, {
					rec: k,
					locale,
					onCopy: () => onCopy(k.secret),
					onEdit: () => {
						setForm({
							workspaceId: k.workspaceId,
							description: k.description,
							access: k.access,
							ipWhitelist: k.ipWhitelist || "0.0.0.0/0",
							allowedModels: k.allowedModels.length > 0 ? k.allowedModels : MODELS.filter((m) => m.chat).map((m) => m.id)
						});
						setEdit(k);
					},
					onDelete: () => setConfirm({
						type: "delete",
						key: k
					}),
					onReset: () => setConfirm({
						type: "reset",
						key: k
					})
				}, k.id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-subtle",
				children: copy.limit
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: createOpen,
				onOpenChange: setCreateOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					title: tab === "temporary" ? copy.createTempTitle : copy.createTitle,
					children: [
						tab === "temporary" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-4 text-sm text-muted",
							children: copy.createTempHint
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyFormFields, {
							form,
							setForm
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 flex justify-end gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								onClick: () => setCreateOpen(false),
								children: copy.cancel
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: submitCreate,
								disabled: busy,
								children: busy ? copy.creating : copy.ok
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: Boolean(edit),
				onOpenChange: (o) => !o && setEdit(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					title: copy.editTitle,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyFormFields, {
							form,
							setForm
						}),
						edit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-xs text-subtle",
							children: copy.enabledHint
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 flex justify-end gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								onClick: () => setEdit(null),
								children: copy.cancel
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: saveEdit,
								children: copy.save
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: Boolean(reveal),
				onOpenChange: (o) => !o && setReveal(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, {
					title: copy.revealTitle,
					children: reveal ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RevealBody, {
						rec: reveal,
						host,
						onCopy
					}) : null
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: Boolean(confirm),
				onOpenChange: (o) => !o && setConfirm(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					title: confirm?.type === "reset" ? copy.resetTitle : copy.deleteTitle,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: confirm?.type === "reset" ? copy.resetBody : copy.deleteBody
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 flex justify-end gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => setConfirm(null),
							children: copy.cancel
						}), confirm?.type === "delete" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "danger",
							onClick: () => {
								if (confirm) useStudio.getState().removeKey(confirm.key.id);
								setConfirm(null);
							},
							children: copy.del
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "danger",
							disabled: busy,
							onClick: () => confirm && submitReset(confirm.key),
							children: busy ? copy.creating : copy.resetNow
						})]
					})]
				})
			})
		]
	});
}
function KeyFormFields({ form, setForm }) {
	const locale = useStudio((s) => s.locale);
	const copy = t(locale);
	const workspaces = useStudio((s) => s.workspaces);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block space-y-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs font-medium text-muted",
					children: copy.owner
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: copy.ownerValue,
					disabled: true
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block space-y-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs font-medium text-muted",
					children: copy.workspace
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NativeSelect, {
					value: form.workspaceId,
					onChange: (e) => setForm({
						...form,
						workspaceId: e.target.value
					}),
					children: workspaces.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: w.id,
						children: w.id === "ws-default" ? copy.wsDefault : w.name
					}, w.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block space-y-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex justify-between text-xs font-medium text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: copy.description }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						form.description.length,
						"/200 · ",
						copy.chars
					] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					maxLength: 200,
					value: form.description,
					placeholder: copy.descriptionPh,
					onChange: (e) => setForm({
						...form,
						description: e.target.value
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
					className: "text-xs font-medium text-muted",
					children: copy.access
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 gap-2",
					children: ["all", "custom"].map((scope) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setForm({
							...form,
							access: scope
						}),
						className: cn("h-11 rounded-md text-sm shadow-[var(--shadow-border)] transition-colors duration-(--motion-quick)", form.access === scope ? "bg-primary-soft font-medium text-primary" : "bg-surface text-muted hover:text-fg"),
						children: scope === "all" ? copy.accessAll : copy.accessCustom
					}, scope))
				})]
			}),
			form.access === "custom" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block space-y-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs font-medium text-muted",
					children: copy.ipList
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: form.ipWhitelist,
					placeholder: copy.ipPh,
					onChange: (e) => setForm({
						...form,
						ipWhitelist: e.target.value
					})
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
					className: "text-xs font-medium text-muted",
					children: copy.modelScope
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-1 sm:grid-cols-2",
					children: MODELS.map((m) => {
						const checked = form.allowedModels.includes(m.id);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex min-h-11 items-center gap-2 rounded-md px-2 text-sm hover:bg-bg",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								className: "size-4 accent-primary",
								checked,
								onChange: () => {
									const next = checked ? form.allowedModels.filter((id) => id !== m.id) : [...form.allowedModels, m.id];
									setForm({
										...form,
										allowedModels: next
									});
								}
							}), m.name]
						}, m.id);
					})
				})]
			})] }) : null
		]
	});
}
function statusOf(rec) {
	if (rec.expiresAt && rec.expiresAt < Date.now()) return "expired";
	return rec.status;
}
function KeyRow({ rec, locale, onCopy, onEdit, onDelete, onReset }) {
	const copy = t(locale);
	const ws = useStudio((s) => s.workspaces).find((w) => w.id === rec.workspaceId);
	const status = statusOf(rec);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
		className: "border-b border-border last:border-0 hover:bg-bg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-4 py-3 font-mono text-xs",
				children: maskKey(rec.secret)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "max-w-40 truncate px-4 py-3 text-muted",
				children: rec.description || copy.never
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-4 py-3 text-muted",
				children: ws?.id === "ws-default" ? copy.wsDefault : ws?.name ?? rec.workspaceId
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-4 py-3 text-muted tabular-nums",
				children: formatDate(rec.createdAt, locale)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-4 py-3 text-muted tabular-nums",
				children: rec.kind === "temporary" ? rec.expiresAt ? formatDate(rec.expiresAt, locale) : copy.never : rec.lastUsedAt ? formatDate(rec.lastUsedAt, locale) : copy.never
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-4 py-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					tone: status === "enabled" ? "success" : status === "expired" ? "warn" : "neutral",
					children: status === "enabled" ? copy.enabled : status === "expired" ? copy.expired : copy.disabled
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-4 py-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RowActions, {
					rec,
					onCopy,
					onEdit,
					onDelete,
					onReset
				})
			})
		]
	});
}
function KeyCard({ rec, locale, onCopy, onEdit, onDelete, onReset }) {
	const copy = t(locale);
	const ws = useStudio((s) => s.workspaces).find((w) => w.id === rec.workspaceId);
	const status = statusOf(rec);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		className: "p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-xs break-all",
					children: maskKey(rec.secret)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					tone: status === "enabled" ? "success" : status === "expired" ? "warn" : "neutral",
					children: status === "enabled" ? copy.enabled : status === "expired" ? copy.expired : copy.disabled
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: rec.description || copy.never
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-xs text-subtle",
				children: [
					ws?.id === "ws-default" ? copy.wsDefault : ws?.name ?? rec.workspaceId,
					" ·",
					" ",
					formatDate(rec.createdAt, locale)
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RowActions, {
					rec,
					onCopy,
					onEdit,
					onDelete,
					onReset
				})
			})
		]
	});
}
function RowActions({ rec, onCopy, onEdit, onDelete, onReset }) {
	const locale = useStudio((s) => s.locale);
	const copy = t(locale);
	const expired = statusOf(rec) === "expired";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-1",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "icon",
				"aria-label": copy.copy,
				onClick: onCopy,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "icon",
				"aria-label": copy.edit,
				onClick: onEdit,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "icon",
					"aria-label": copy.more,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ellipsis, {})
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
					disabled: expired,
					onSelect: () => useStudio.getState().updateKey(rec.id, { status: rec.status === "enabled" ? "disabled" : "enabled" }),
					children: rec.status === "enabled" ? copy.disable : copy.enable
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
					onSelect: onReset,
					children: copy.reset
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
					tone: "danger",
					onSelect: onDelete,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" }), copy.del]
				})
			] })] })
		]
	});
}
function RevealBody({ rec, host, onCopy }) {
	const locale = useStudio((s) => s.locale);
	const copy = t(locale);
	const hours = rec.expiresAt ? Math.max(0, Math.round((rec.expiresAt - Date.now()) / 36e5)) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-md bg-warn-soft px-3 py-2 text-sm text-warn",
				children: copy.revealWarn
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block space-y-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs font-medium text-muted",
					children: copy.colKey
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						readOnly: true,
						value: rec.secret,
						className: "font-mono text-xs"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						"aria-label": copy.copy,
						onClick: () => onCopy(rec.secret),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block space-y-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs font-medium text-muted",
					children: copy.apiHost
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						readOnly: true,
						value: host,
						className: "font-mono text-xs"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						"aria-label": copy.copyHost,
						onClick: () => host && onCopy(host),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {})
					})]
				})]
			}),
			hours !== null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted",
				children: [
					hours,
					" ",
					copy.hoursLeft
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: copy.forever
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap justify-end gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					onClick: () => downloadText(`${copy.keyFile}.txt`, `Lúmen Studio API Key\nRegion: ${rec.regionId}\nHost: ${host}\nKey: ${rec.secret}\n`),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}), copy.download]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => onCopy(rec.secret),
					children: copy.copy
				})]
			})
		]
	});
}
function Home() {
	const locale = useStudio((s) => s.locale);
	const copy = t(locale);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConsoleShell, {
		title: copy.apiTitle,
		hint: copy.apiHint,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeysManager, {})
	});
}
//#endregion
export { Home as component };
