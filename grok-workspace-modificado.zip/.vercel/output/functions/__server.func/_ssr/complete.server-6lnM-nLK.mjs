import { rateLimit, verifySignedKey } from "./api-keys.server-Ce1uecfW.mjs";
import { i as MODEL_RUNTIME } from "./models-CJww7k-s.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/complete.server-6lnM-nLK.js
var CORS = {
	"Access-Control-Allow-Origin": "*",
	"Access-Control-Allow-Headers": "Authorization, Content-Type",
	"Access-Control-Allow-Methods": "GET, POST, OPTIONS"
};
var MAX_MESSAGES = 12;
var MAX_CONTENT = 4e3;
function sanitizeMessages(messages) {
	const allowed = /* @__PURE__ */ new Set([
		"system",
		"user",
		"assistant"
	]);
	const next = [];
	for (const m of messages) {
		if (!allowed.has(m.role)) continue;
		const content = typeof m.content === "string" ? m.content.trim() : "";
		if (!content) continue;
		next.push({
			role: m.role,
			content: content.slice(0, MAX_CONTENT)
		});
		if (next.length >= MAX_MESSAGES) break;
	}
	return next;
}
async function complete(opts) {
	const verified = verifySignedKey(opts.key);
	if (!verified) return {
		ok: false,
		code: "invalid_key",
		message: "Invalid API key.",
		status: 401
	};
	const runtime = MODEL_RUNTIME[opts.model];
	if (!runtime) return {
		ok: false,
		code: "bad_model",
		message: "Unknown or non-chat model.",
		status: 400
	};
	const messages = sanitizeMessages(opts.messages);
	if (!messages.length || messages[messages.length - 1]?.role !== "user") return {
		ok: false,
		code: "bad_request",
		message: "Provide messages ending with a user turn.",
		status: 400
	};
	if (!rateLimit(verified.id).ok) return {
		ok: false,
		code: "rate_limited",
		message: "Rate limit reached. Try again later.",
		status: 429
	};
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		code: "ai_unavailable",
		message: "Model service is unavailable in this environment.",
		status: 503
	};
	let res;
	try {
		res = await fetch("https://api.x.ai/v1/chat/completions", {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${apiKey}`
			},
			body: JSON.stringify({
				model: runtime.xai,
				messages,
				max_tokens: runtime.maxTokens,
				temperature: .7
			}),
			signal: AbortSignal.timeout(25e3)
		});
	} catch {
		return {
			ok: false,
			code: "upstream",
			message: "Upstream timeout.",
			status: 504
		};
	}
	if (!res.ok) return {
		ok: false,
		code: "upstream",
		message: `Model provider error ${res.status}.`,
		status: 502
	};
	const body = await res.json();
	return {
		ok: true,
		text: body.choices?.[0]?.message?.content ?? "",
		tokensIn: body.usage?.prompt_tokens ?? 0,
		tokensOut: body.usage?.completion_tokens ?? 0,
		model: opts.model
	};
}
function bearerKey(request) {
	return (request.headers.get("authorization") ?? "").match(/^Bearer\s+(.+)$/i)?.[1]?.trim() ?? "";
}
//#endregion
export { CORS, bearerKey, complete };
