import { t as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-A6pJPYTF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/chat-b7dfVTb5.js
var completeChat_createServerFn_handler = createServerRpc({
	id: "58260998c9cd54ce41b1aca7738021c1654c6659d23c7ce9547eebc567407f4f",
	name: "completeChat",
	filename: "src/lib/chat.ts"
}, (opts) => completeChat.__executeServer(opts));
var completeChat = createServerFn({ method: "POST" }).validator((input) => input).handler(completeChat_createServerFn_handler, async ({ data }) => {
	const { complete } = await import("./complete.server-6lnM-nLK.mjs");
	return complete(data);
});
//#endregion
export { completeChat_createServerFn_handler };
