import { createHmac, randomBytes, timingSafeEqual } from "node:crypto";
//#region node_modules/.nitro/vite/services/ssr/assets/api-keys.server-Ce1uecfW.js
var PREFIX = "sk-lx-";
var ID_LEN = 32;
var SIG_LEN = 12;
function signingSecret() {
	return process.env.XAI_API_KEY || "lumen-studio-signing-secret";
}
function issueSignedKey() {
	const id = randomBytes(ID_LEN / 2).toString("hex");
	return {
		id,
		key: `${PREFIX}${id}${createHmac("sha256", signingSecret()).update(id).digest("hex").slice(0, SIG_LEN)}`,
		issuedAt: Date.now()
	};
}
function verifySignedKey(key) {
	if (typeof key !== "string" || key.length !== 50) return null;
	if (!key.startsWith(PREFIX)) return null;
	const id = key.slice(6, 38);
	const sig = key.slice(38);
	if (!/^[0-9a-f]+$/.test(id) || !/^[0-9a-f]+$/.test(sig)) return null;
	const expected = createHmac("sha256", signingSecret()).update(id).digest("hex").slice(0, SIG_LEN);
	const a = Buffer.from(sig);
	const b = Buffer.from(expected);
	if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
	return {
		id,
		key
	};
}
var buckets = /* @__PURE__ */ new Map();
var WINDOW_MS = 36e5;
var MAX_PER_WINDOW = 40;
function rateLimit(id) {
	const now = Date.now();
	const current = buckets.get(id);
	if (!current || now > current.resetAt) {
		buckets.set(id, {
			count: 1,
			resetAt: now + WINDOW_MS
		});
		return {
			ok: true,
			remaining: 39
		};
	}
	if (current.count >= MAX_PER_WINDOW) return {
		ok: false,
		retryAt: current.resetAt
	};
	current.count += 1;
	return {
		ok: true,
		remaining: MAX_PER_WINDOW - current.count
	};
}
//#endregion
export { issueSignedKey, rateLimit, verifySignedKey };
