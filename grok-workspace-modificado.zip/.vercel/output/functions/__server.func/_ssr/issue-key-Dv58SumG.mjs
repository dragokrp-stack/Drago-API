import { t as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-A6pJPYTF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/issue-key-Dv58SumG.js
var issueApiKey_createServerFn_handler = createServerRpc({
	id: "8a394adfbd1c1cbbab4854500a44c6954e094b5fcc62cd97146f20a2f1cb1d90",
	name: "issueApiKey",
	filename: "src/lib/issue-key.ts"
}, (opts) => issueApiKey.__executeServer(opts));
var issueApiKey = createServerFn({ method: "POST" }).handler(issueApiKey_createServerFn_handler, async () => {
	const { issueSignedKey } = await import("./api-keys.server-Ce1uecfW.mjs");
	return issueSignedKey();
});
//#endregion
export { issueApiKey_createServerFn_handler };
