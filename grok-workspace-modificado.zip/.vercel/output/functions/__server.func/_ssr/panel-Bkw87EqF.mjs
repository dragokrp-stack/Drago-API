import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { b as Link, p as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as require_jsx_runtime, r as Slot } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as REGIONS } from "./models-CJww7k-s.mjs";
import { d as KeyRound, f as Globe, i as Sparkles, l as Menu, m as FlaskConical, o as Search, p as Gauge, t as X, u as LayoutGrid, y as BookOpen } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/panel-Bkw87EqF.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LogoMark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className,
		"aria-hidden": "true",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			width: "32",
			height: "32",
			rx: "7",
			fill: "currentColor"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M9 8h5.2c4.4 0 7.4 2.6 7.4 6.6 0 4.1-3.1 6.7-7.6 6.7H13.2V24H9V8zm4.2 3.1v5.2h1.1c2.2 0 3.5-1.1 3.5-2.6 0-1.5-1.2-2.6-3.4-2.6H13.2z",
			fill: "#fff"
		})]
	});
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function formatDate(ts, locale) {
	return new Intl.DateTimeFormat(locale === "pt" ? "pt-BR" : "en-US", {
		dateStyle: "short",
		timeStyle: "short"
	}).format(new Date(ts));
}
function formatNumber(n, locale) {
	return new Intl.NumberFormat(locale === "pt" ? "pt-BR" : "en-US").format(n);
}
function maskKey(secret) {
	if (secret.length < 16) return "sk-lx-****";
	return `${secret.slice(0, 10)}****${secret.slice(-4)}`;
}
function downloadText(filename, contents) {
	const blob = new Blob([contents], { type: "text/plain;charset=utf-8" });
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = filename;
	a.click();
	URL.revokeObjectURL(url);
}
async function copyText(text) {
	await navigator.clipboard.writeText(text);
}
function parseIpList(raw) {
	return raw.split(/[,\n]/).map((s) => s.trim()).filter(Boolean).slice(0, 20);
}
function Badge({ className, tone = "neutral", children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex h-6 items-center rounded-full px-2 text-xs font-medium", tone === "neutral" && "bg-bg text-muted", tone === "success" && "bg-success-soft text-success", tone === "warn" && "bg-warn-soft text-warn", tone === "danger" && "bg-danger-soft text-danger", tone === "accent" && "bg-primary-soft text-primary", className),
		children
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md font-medium transition-[opacity,transform,background-color,color,box-shadow] duration-(--motion-quick) ease-(--ease-out) focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/40 disabled:pointer-events-none disabled:opacity-40 active:enabled:scale-95 [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			primary: "bg-primary text-primary-fg shadow-sm hover:bg-primary-hover",
			outline: "bg-surface text-fg shadow-[var(--shadow-border)] hover:bg-bg",
			ghost: "text-fg hover:bg-bg",
			danger: "bg-danger text-primary-fg hover:opacity-90",
			dangerOutline: "bg-surface text-danger shadow-[var(--shadow-border)] hover:bg-danger-soft"
		},
		size: {
			sm: "h-8 px-3 text-xs",
			md: "h-10 px-4 text-sm",
			lg: "h-11 px-5 text-sm",
			icon: "size-10",
			iconSm: "size-8"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
var Button = (0, import_react.forwardRef)(function Button({ className, variant, size, type = "button", asChild, ...props }, ref) {
	const classes = cn(buttonVariants({
		variant,
		size
	}), className);
	if (asChild) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slot, {
		ref,
		className: classes,
		...props
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		ref,
		type,
		className: classes,
		...props
	});
});
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn("h-10 w-full rounded-md bg-surface px-3 text-sm text-fg shadow-[inset_0_0_0_1px_var(--color-border)] placeholder:text-subtle", "transition-[box-shadow] duration-(--motion-quick) ease-(--ease-out)", "focus-visible:outline-none focus-visible:shadow-[inset_0_0_0_1px_var(--color-primary),0_0_0_3px_color-mix(in_oklab,var(--color-primary)_22%,transparent)]", "disabled:opacity-50", className),
		...props
	});
}
function Textarea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("min-h-20 w-full rounded-md bg-surface px-3 py-2 text-sm text-fg shadow-[inset_0_0_0_1px_var(--color-border)] placeholder:text-subtle", "transition-[box-shadow] duration-(--motion-quick) ease-(--ease-out)", "focus-visible:outline-none focus-visible:shadow-[inset_0_0_0_1px_var(--color-primary),0_0_0_3px_color-mix(in_oklab,var(--color-primary)_22%,transparent)]", className),
		...props
	});
}
function NativeSelect({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
		className: cn("h-10 w-full rounded-md bg-surface px-3 text-sm text-fg shadow-[inset_0_0_0_1px_var(--color-border)]", "transition-[box-shadow] duration-(--motion-quick) ease-(--ease-out)", "focus-visible:outline-none focus-visible:shadow-[inset_0_0_0_1px_var(--color-primary),0_0_0_3px_color-mix(in_oklab,var(--color-primary)_22%,transparent)]", className),
		...props,
		children
	});
}
var catalog = {
	pt: {
		product: "Lúmen Studio",
		tagline: "Console de modelos",
		search: "Buscar chaves, modelos…",
		region: "Região",
		account: "Conta principal",
		free: "Gratuito",
		navPlayground: "Playground",
		navModels: "Modelos",
		navDashboard: "Painel",
		navApiKey: "API Key",
		navUsage: "Uso e cota",
		navWorkspaces: "Espaços de trabalho",
		navDocs: "Primeiros passos",
		breadcrumbDash: "Painel",
		apiTitle: "Gerenciamento de API Key",
		apiHint: "Crie, copie e revogue chaves. Cada região tem chaves e endpoint próprios — não misture.",
		banner: "Serviço ativo. Conta gratuita permanente — sem verificação de idade e sem pagamento.",
		tabStandard: "API-Key",
		tabTemp: "Chave temporária",
		createKey: "Criar API Key",
		createTemp: "Criar chave temporária",
		emptyTitle: "Nenhuma API Key nesta região",
		emptyBody: "Gere uma chave para autenticar chamadas. O valor completo aparece só uma vez — copie e guarde.",
		colKey: "API Key",
		colDesc: "Descrição",
		colWorkspace: "Espaço",
		colCreated: "Criada em",
		colStatus: "Status",
		colExpires: "Expira",
		colActions: "Ações",
		enabled: "Ativa",
		disabled: "Desativada",
		expired: "Expirada",
		copy: "Copiar",
		copied: "Copiado",
		edit: "Editar",
		disable: "Desativar",
		enable: "Ativar",
		reset: "Redefinir",
		del: "Excluir",
		cancel: "Cancelar",
		ok: "OK",
		save: "Salvar",
		workspace: "Espaço de trabalho",
		description: "Descrição",
		descriptionPh: "Ex.: app de produção, testes locais…",
		access: "Escopo de acesso",
		accessAll: "Todos os modelos",
		accessCustom: "Personalizado",
		ipList: "Lista de IPs (IPv4/CIDR, até 20)",
		ipPh: "0.0.0.0/0",
		modelScope: "Modelos permitidos",
		createTitle: "Criar API Key",
		createTempTitle: "Criar chave temporária",
		createTempHint: "Válida por 24 horas. Ideal para testes e CI.",
		revealTitle: "Guarde esta chave agora",
		revealWarn: "A chave em texto claro não será mostrada de novo depois de fechar. Quem a tiver pode chamar os modelos em seu nome.",
		apiHost: "API Host",
		download: "Baixar .txt",
		close: "Fechar",
		deleteTitle: "Excluir API Key?",
		deleteBody: "A chave deixa de autenticar imediatamente. Isso não pode ser desfeito.",
		resetTitle: "Redefinir API Key?",
		resetBody: "O valor atual deixa de valer. Um novo segredo será gerado.",
		editTitle: "Editar API Key",
		limit: "Até 20 chaves por espaço nesta região.",
		modelsTitle: "Catálogo de modelos",
		modelsHint: "Todos os modelos da cota gratuita. Sem cartão, sem fatura.",
		tryNow: "Experimentar",
		apiRef: "Referência da API",
		playgroundTitle: "Playground",
		playgroundHint: "Teste um modelo com uma chave desta região. Chamadas descontam da cota gratuita.",
		selectKey: "API Key",
		selectModel: "Modelo",
		needKey: "Crie uma API Key nesta região para conversar.",
		send: "Enviar",
		promptPh: "Escreva uma mensagem…",
		thinking: "Gerando…",
		noChat: "Este modelo não conversa no playground. Use a API.",
		usageTitle: "Uso e cota",
		usageHint: "Cota gratuita permanente. Nada a pagar — o serviço continua.",
		quota: "Cota gratuita",
		tokensUsed: "Tokens usados",
		requests: "Requisições",
		remaining: "Restante",
		neverPay: "Sem faturamento. Sem verificação de idade. Sem cartão.",
		wsTitle: "Espaços de trabalho",
		wsHint: "Isole projetos e chaves. Cada espaço admite até 20 API Keys por região.",
		wsCreate: "Novo espaço",
		wsName: "Nome do espaço",
		wsDefault: "Espaço padrão",
		docsTitle: "Primeiros passos",
		docsHint: "Chame os modelos com a API compatível com OpenAI. Sem cadastro extra.",
		step1: "1. Crie uma API Key",
		step2: "2. Defina o host e a chave",
		step3: "3. Faça a primeira chamada",
		langPt: "Português",
		langEn: "English",
		openMenu: "Abrir menu",
		closeMenu: "Fechar menu",
		allRegions: "Chaves não atravessam regiões.",
		lastUsed: "Último uso",
		never: "—",
		filter: "Filtrar",
		noMatch: "Nenhum resultado para essa busca.",
		owner: "Conta de origem",
		ownerValue: "Conta principal",
		chars: "até 200 caracteres",
		newChat: "Nova conversa",
		you: "Você",
		assistant: "Assistente",
		creating: "Criando…",
		saving: "Salvando…",
		errInvalidKey: "API Key inválida ou desativada.",
		errRate: "Limite de chamadas desta chave. Tente mais tarde.",
		errAi: "O serviço de modelo está indisponível no momento.",
		errModel: "Este modelo não aceita chat.",
		errUp: "Falha ao chamar o modelo. Tente de novo.",
		errIssue: "Não foi possível emitir a chave. Tente de novo.",
		quotaBar: "da cota gratuita",
		last14: "Últimos 14 dias",
		tokensIn: "Entrada",
		tokensOut: "Saída",
		goCreate: "Criar chave",
		copyHost: "Copiar host",
		exampleCurl: "cURL",
		examplePy: "Python",
		exampleJs: "Node.js",
		pickModel: "Escolha um modelo de chat",
		wsInUse: "Exclua as chaves deste espaço antes.",
		wsDelete: "Excluir espaço",
		wsEmpty: "Nenhum outro espaço. O padrão cobre todos os modelos.",
		family: "Família",
		context: "Contexto",
		rpm: "RPM",
		modality: "Modalidade",
		text: "Texto",
		vision: "Visão",
		image: "Imagem",
		embed: "Embedding",
		notFound: "Página não encontrada",
		notFoundBody: "Esse caminho não existe no console.",
		backHome: "Ir para API Key",
		more: "Mais",
		resetNow: "Redefinir chave",
		enabledHint: "Chaves desativadas não autenticam chamadas.",
		keyFile: "lumen-api-key",
		forever: "Permanente",
		hoursLeft: "h restantes",
		used: "usado"
	},
	en: {
		product: "Lúmen Studio",
		tagline: "Model console",
		search: "Search keys, models…",
		region: "Region",
		account: "Primary account",
		free: "Free",
		navPlayground: "Playground",
		navModels: "Models",
		navDashboard: "Dashboard",
		navApiKey: "API Key",
		navUsage: "Usage & quota",
		navWorkspaces: "Workspaces",
		navDocs: "Get started",
		breadcrumbDash: "Dashboard",
		apiTitle: "API Key management",
		apiHint: "Create, copy, and revoke keys. Each region has its own keys and endpoint — do not mix them.",
		banner: "Service is on. Permanent free account — no age check and no payment.",
		tabStandard: "API-Key",
		tabTemp: "Temporary key",
		createKey: "Create API Key",
		createTemp: "Create temporary key",
		emptyTitle: "No API keys in this region",
		emptyBody: "Generate a key to authenticate calls. The full value is shown only once — copy it and store it.",
		colKey: "API Key",
		colDesc: "Description",
		colWorkspace: "Workspace",
		colCreated: "Created",
		colStatus: "Status",
		colExpires: "Expires",
		colActions: "Actions",
		enabled: "Enabled",
		disabled: "Disabled",
		expired: "Expired",
		copy: "Copy",
		copied: "Copied",
		edit: "Edit",
		disable: "Disable",
		enable: "Enable",
		reset: "Reset",
		del: "Delete",
		cancel: "Cancel",
		ok: "OK",
		save: "Save",
		workspace: "Workspace",
		description: "Description",
		descriptionPh: "e.g. production app, local tests…",
		access: "Access scope",
		accessAll: "All models",
		accessCustom: "Custom",
		ipList: "IP allowlist (IPv4/CIDR, up to 20)",
		ipPh: "0.0.0.0/0",
		modelScope: "Allowed models",
		createTitle: "Create API Key",
		createTempTitle: "Create temporary key",
		createTempHint: "Valid for 24 hours. Best for tests and CI.",
		revealTitle: "Save this key now",
		revealWarn: "The plaintext key will not be shown again after you close this dialog. Anyone with it can call models on your behalf.",
		apiHost: "API Host",
		download: "Download .txt",
		close: "Close",
		deleteTitle: "Delete API Key?",
		deleteBody: "The key stops authenticating immediately. This cannot be undone.",
		resetTitle: "Reset API Key?",
		resetBody: "The current secret stops working. A new one will be issued.",
		editTitle: "Edit API Key",
		limit: "Up to 20 keys per workspace in this region.",
		modelsTitle: "Model catalog",
		modelsHint: "Every model is on the free quota. No card, no invoice.",
		tryNow: "Try now",
		apiRef: "API reference",
		playgroundTitle: "Playground",
		playgroundHint: "Try a model with a key from this region. Calls count against the free quota.",
		selectKey: "API Key",
		selectModel: "Model",
		needKey: "Create an API Key in this region to start chatting.",
		send: "Send",
		promptPh: "Write a message…",
		thinking: "Generating…",
		noChat: "This model has no playground chat. Use the API.",
		usageTitle: "Usage & quota",
		usageHint: "Permanent free quota. Nothing to pay — the service keeps running.",
		quota: "Free quota",
		tokensUsed: "Tokens used",
		requests: "Requests",
		remaining: "Remaining",
		neverPay: "No billing. No age verification. No card.",
		wsTitle: "Workspaces",
		wsHint: "Isolate projects and keys. Each workspace allows 20 API keys per region.",
		wsCreate: "New workspace",
		wsName: "Workspace name",
		wsDefault: "Default workspace",
		docsTitle: "Get started",
		docsHint: "Call models with the OpenAI-compatible API. No extra signup.",
		step1: "1. Create an API Key",
		step2: "2. Set the host and the key",
		step3: "3. Make the first call",
		langPt: "Português",
		langEn: "English",
		openMenu: "Open menu",
		closeMenu: "Close menu",
		allRegions: "Keys do not work across regions.",
		lastUsed: "Last used",
		never: "—",
		filter: "Filter",
		noMatch: "No results for that search.",
		owner: "Owner account",
		ownerValue: "Primary account",
		chars: "up to 200 characters",
		newChat: "New chat",
		you: "You",
		assistant: "Assistant",
		creating: "Creating…",
		saving: "Saving…",
		errInvalidKey: "Invalid or disabled API key.",
		errRate: "This key hit its rate limit. Try later.",
		errAi: "The model service is unavailable right now.",
		errModel: "This model does not support chat.",
		errUp: "The model call failed. Try again.",
		errIssue: "Could not issue the key. Try again.",
		quotaBar: "of free quota",
		last14: "Last 14 days",
		tokensIn: "Input",
		tokensOut: "Output",
		goCreate: "Create key",
		copyHost: "Copy host",
		exampleCurl: "cURL",
		examplePy: "Python",
		exampleJs: "Node.js",
		pickModel: "Pick a chat model",
		wsInUse: "Delete the keys in this workspace first.",
		wsDelete: "Delete workspace",
		wsEmpty: "No extra workspaces. Default covers every model.",
		family: "Family",
		context: "Context",
		rpm: "RPM",
		modality: "Modality",
		text: "Text",
		vision: "Vision",
		image: "Image",
		embed: "Embedding",
		notFound: "Page not found",
		notFoundBody: "That path does not exist in the console.",
		backHome: "Go to API Key",
		more: "More",
		resetNow: "Reset key",
		enabledHint: "Disabled keys cannot authenticate calls.",
		keyFile: "lumen-api-key",
		forever: "Permanent",
		hoursLeft: "h left",
		used: "used"
	}
};
function t(locale) {
	return catalog[locale];
}
var DEFAULT_WS = {
	id: "ws-default",
	name: "default",
	createdAt: Date.now()
};
var EMPTY_USAGE = {
	requests: 0,
	tokensIn: 0,
	tokensOut: 0,
	daily: []
};
function todayKey() {
	return (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
}
var useStudio = create()(persist((set, get) => ({
	locale: "pt",
	regionId: "sa-east-1",
	hydrated: false,
	query: "",
	workspaces: [DEFAULT_WS],
	keys: [],
	usage: EMPTY_USAGE,
	setLocale: (locale) => set({ locale }),
	setRegion: (regionId) => set({
		regionId,
		query: ""
	}),
	setQuery: (query) => set({ query }),
	setHydrated: (hydrated) => set({ hydrated }),
	addWorkspace: (name) => {
		const id = `ws-${crypto.randomUUID().slice(0, 8)}`;
		set({ workspaces: [...get().workspaces, {
			id,
			name: name.trim() || "workspace",
			createdAt: Date.now()
		}] });
		return id;
	},
	renameWorkspace: (id, name) => set({ workspaces: get().workspaces.map((w) => w.id === id ? {
		...w,
		name: name.trim() || w.name
	} : w) }),
	removeWorkspace: (id) => {
		if (id === "ws-default") return {
			ok: false,
			reason: "default"
		};
		if (get().keys.some((k) => k.workspaceId === id)) return {
			ok: false,
			reason: "in_use"
		};
		set({ workspaces: get().workspaces.filter((w) => w.id !== id) });
		return { ok: true };
	},
	addKey: (key) => {
		if (get().keys.filter((k) => k.workspaceId === key.workspaceId && k.regionId === key.regionId).length >= 20) return {
			ok: false,
			reason: "limit"
		};
		set({ keys: [key, ...get().keys] });
		return { ok: true };
	},
	updateKey: (id, patch) => set({ keys: get().keys.map((k) => k.id === id ? {
		...k,
		...patch
	} : k) }),
	removeKey: (id) => set({ keys: get().keys.filter((k) => k.id !== id) }),
	touchKey: (id) => set({ keys: get().keys.map((k) => k.id === id ? {
		...k,
		lastUsedAt: Date.now()
	} : k) }),
	addUsage: (tokensIn, tokensOut) => {
		const u = get().usage;
		const daily = Array.isArray(u.daily) ? [...u.daily] : [];
		const day = todayKey();
		const tokens = tokensIn + tokensOut;
		const idx = daily.findIndex((d) => d.day === day);
		if (idx >= 0) {
			const current = daily[idx];
			daily[idx] = {
				day,
				requests: current.requests + 1,
				tokens: current.tokens + tokens
			};
		} else daily.push({
			day,
			requests: 1,
			tokens
		});
		set({ usage: {
			requests: u.requests + 1,
			tokensIn: u.tokensIn + tokensIn,
			tokensOut: u.tokensOut + tokensOut,
			daily: daily.slice(-14)
		} });
	}
}), {
	name: "lumen-studio-v1",
	partialize: (s) => ({
		locale: s.locale,
		regionId: s.regionId,
		workspaces: s.workspaces,
		keys: s.keys,
		usage: s.usage
	}),
	onRehydrateStorage: () => () => {
		useStudio.getState().setHydrated(true);
	}
}));
function useVisibleKeys(kind) {
	const keys = useStudio((s) => s.keys);
	const regionId = useStudio((s) => s.regionId);
	const query = useStudio((s) => s.query);
	if (!useStudio((s) => s.hydrated)) return [];
	const q = query.trim().toLowerCase();
	const now = Date.now();
	return keys.filter((k) => {
		if (k.regionId !== regionId) return false;
		if (k.kind !== kind) return false;
		if (k.kind === "temporary" && k.expiresAt && k.expiresAt < now) {}
		if (!q) return true;
		return k.secret.toLowerCase().includes(q) || k.description.toLowerCase().includes(q) || k.id.toLowerCase().includes(q);
	});
}
function useHydrated() {
	return useStudio((s) => s.hydrated);
}
var NAV = [
	{
		to: "/playground",
		key: "navPlayground",
		icon: FlaskConical
	},
	{
		to: "/models",
		key: "navModels",
		icon: Sparkles
	},
	{
		to: "/",
		key: "navApiKey",
		icon: KeyRound
	},
	{
		to: "/usage",
		key: "navUsage",
		icon: Gauge
	},
	{
		to: "/workspaces",
		key: "navWorkspaces",
		icon: LayoutGrid
	},
	{
		to: "/docs",
		key: "navDocs",
		icon: BookOpen
	}
];
function ConsoleShell({ title, hint, children, actions }) {
	const locale = useStudio((s) => s.locale);
	const regionId = useStudio((s) => s.regionId);
	const query = useStudio((s) => s.query);
	const copy = t(locale);
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const [open, setOpen] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		document.documentElement.lang = locale === "pt" ? "pt-BR" : "en";
	}, [locale]);
	(0, import_react.useEffect)(() => {
		const finish = () => useStudio.getState().setHydrated(true);
		const unsub = useStudio.persist.onFinishHydration(finish);
		if (useStudio.persist.hasHydrated()) finish();
		return unsub;
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "sticky top-0 z-40 flex h-14 items-center gap-3 border-b border-border bg-header px-3 sm:px-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "iconSm",
					className: "lg:hidden",
					"aria-label": open ? copy.closeMenu : copy.openMenu,
					onClick: () => setOpen((v) => !v),
					children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "flex min-w-0 shrink-0 items-center gap-2 text-fg",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogoMark, { className: "size-7 text-primary" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "hidden text-sm font-semibold tracking-tight sm:inline",
							children: copy.product
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "hidden text-xs text-subtle lg:inline",
							children: copy.tagline
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative mx-auto min-w-0 max-w-md flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-subtle" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: query,
						onChange: (e) => useStudio.getState().setQuery(e.target.value),
						placeholder: copy.search,
						className: "h-9 pl-9",
						"aria-label": copy.search
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "ml-auto flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "hidden items-center gap-2 text-xs text-muted sm:flex",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, { className: "size-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NativeSelect, {
								className: "h-9 w-40 text-xs",
								value: regionId,
								onChange: (e) => useStudio.getState().setRegion(e.target.value),
								"aria-label": copy.region,
								children: REGIONS.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
									value: r.id,
									children: [
										locale === "pt" ? r.city : r.cityEn,
										" (",
										r.code,
										")"
									]
								}, r.id))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(NativeSelect, {
							className: "h-9 w-16 text-xs",
							value: locale,
							onChange: (e) => useStudio.getState().setLocale(e.target.value === "en" ? "en" : "pt"),
							"aria-label": "Language",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "pt",
								children: "PT"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "en",
								children: "EN"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "hidden items-center gap-2 rounded-full bg-bg px-2 py-1 sm:flex",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "size-6 rounded-full bg-primary text-center text-xs leading-6 font-semibold text-primary-fg",
									children: "LS"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "pr-1 text-xs text-muted",
									children: copy.account
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: "accent",
									children: copy.free
								})
							]
						})
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex",
			children: [
				open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "fixed inset-0 z-30 bg-fg/30 lg:hidden",
					"aria-label": copy.closeMenu,
					onClick: () => setOpen(false)
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: cn("fixed top-14 bottom-0 z-30 w-60 overflow-y-auto border-r border-border bg-sidebar p-3 transition-transform duration-(--motion-fast) ease-(--ease-out) lg:sticky lg:h-[calc(100dvh-3.5rem)] lg:translate-x-0", open ? "translate-x-0" : "-translate-x-full lg:translate-x-0"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "px-2 pb-2 text-xs font-semibold tracking-wide text-subtle uppercase",
							children: copy.navDashboard
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
							className: "flex flex-col gap-0.5",
							children: NAV.map((item) => {
								const active = item.to === "/" ? pathname === "/" : pathname === item.to || pathname.startsWith(`${item.to}/`);
								const Icon = item.icon;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: item.to,
									onClick: () => setOpen(false),
									className: cn("flex h-11 items-center gap-2 rounded-md px-2.5 text-sm transition-colors duration-(--motion-quick)", active ? "bg-nav-active font-medium text-primary" : "text-muted hover:bg-bg hover:text-fg"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), copy[item.key]]
								}, item.to);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 space-y-2 px-2 lg:hidden",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium text-muted",
								children: copy.region
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NativeSelect, {
								value: regionId,
								onChange: (e) => useStudio.getState().setRegion(e.target.value),
								"aria-label": copy.region,
								children: REGIONS.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
									value: r.id,
									children: [
										locale === "pt" ? r.city : r.cityEn,
										" (",
										r.code,
										")"
									]
								}, r.id))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 px-2 text-xs leading-5 text-subtle",
							children: copy.allRegions
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
					className: "min-w-0 flex-1 px-4 py-5 sm:px-6 lg:px-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mb-3 text-xs text-subtle",
							children: [
								copy.breadcrumbDash,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mx-1.5",
									children: "/"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted",
									children: title
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-5 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "text-xl font-semibold tracking-tight",
								children: title
							}), hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 max-w-2xl text-sm text-muted",
								children: hint
							}) : null] }), actions ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap gap-2",
								children: actions
							}) : null]
						}),
						children
					]
				})
			]
		})]
	});
}
function Panel({ className, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("rounded-lg bg-surface shadow-[var(--shadow-border)]", className),
		children
	});
}
//#endregion
export { useStudio as _, NativeSelect as a, cn as c, formatDate as d, formatNumber as f, useHydrated as g, t as h, Input as i, copyText as l, parseIpList as m, Button as n, Panel as o, maskKey as p, ConsoleShell as r, Textarea as s, Badge as t, downloadText as u, useVisibleKeys as v };
