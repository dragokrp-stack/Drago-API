//#region node_modules/.nitro/vite/services/ssr/assets/models-CJww7k-s.js
var REGIONS = [
	{
		id: "sa-east-1",
		city: "São Paulo",
		cityEn: "São Paulo",
		code: "sa-east-1"
	},
	{
		id: "eu-west-1",
		city: "Lisboa",
		cityEn: "Lisbon",
		code: "eu-west-1"
	},
	{
		id: "us-east-1",
		city: "Virgínia",
		cityEn: "Virginia",
		code: "us-east-1"
	}
];
var MODELS = [
	{
		id: "lumen-max",
		name: "Lúmen Max",
		family: "Flagship",
		modality: "text",
		blurbPt: "Raciocínio profundo para código, pesquisa e tarefas longas.",
		blurbEn: "Deep reasoning for code, research, and long-horizon work.",
		context: "128K",
		chat: true,
		rpm: 60
	},
	{
		id: "lumen-plus",
		name: "Lúmen Plus",
		family: "Flagship",
		modality: "text",
		blurbPt: "Equilíbrio entre qualidade, custo e velocidade no dia a dia.",
		blurbEn: "Balanced quality, cost, and speed for everyday work.",
		context: "128K",
		chat: true,
		rpm: 120
	},
	{
		id: "lumen-flash",
		name: "Lúmen Flash",
		family: "Fast",
		modality: "text",
		blurbPt: "Respostas rápidas para classificação, resumo e chat simples.",
		blurbEn: "Fast replies for classification, summaries, and light chat.",
		context: "64K",
		chat: true,
		rpm: 240
	},
	{
		id: "lumen-vision",
		name: "Lúmen Vision",
		family: "Multimodal",
		modality: "vision",
		blurbPt: "Entende imagens e texto no mesmo turno — gráficos, UI, documentos.",
		blurbEn: "Reads images and text together — charts, UI, documents.",
		context: "64K",
		chat: true,
		rpm: 60
	},
	{
		id: "lumen-image",
		name: "Lúmen Image",
		family: "Media",
		modality: "image",
		blurbPt: "Geração de imagens a partir de instruções detalhadas.",
		blurbEn: "Image generation from detailed instructions.",
		context: "—",
		chat: false,
		rpm: 20
	},
	{
		id: "lumen-embed",
		name: "Lúmen Embed",
		family: "Retrieval",
		modality: "embed",
		blurbPt: "Embeddings densos para busca semântica e RAG.",
		blurbEn: "Dense embeddings for semantic search and RAG.",
		context: "8K",
		chat: false,
		rpm: 300
	}
];
var CHAT_MODELS = MODELS.filter((m) => m.chat);
var MODEL_RUNTIME = {
	"lumen-max": {
		xai: "grok-4.5",
		maxTokens: 2048
	},
	"lumen-plus": {
		xai: "grok-4.5",
		maxTokens: 1024
	},
	"lumen-flash": {
		xai: "grok-4.5",
		maxTokens: 512
	},
	"lumen-vision": {
		xai: "grok-4.5",
		maxTokens: 1024
	}
};
var FREE_TOKEN_QUOTA = 1e6;
function apiHost(origin) {
	return `${origin.replace(/\/$/, "")}/api/v1`;
}
function regionLabel(id, locale) {
	const region = REGIONS.find((r) => r.id === id);
	if (!region) return id;
	return `${locale === "pt" ? region.city : region.cityEn} (${region.code})`;
}
//#endregion
export { REGIONS as a, MODEL_RUNTIME as i, FREE_TOKEN_QUOTA as n, apiHost as o, MODELS as r, regionLabel as s, CHAT_MODELS as t };
