import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { r as MODELS } from "./models-CJww7k-s.mjs";
import { _ as useStudio, h as t, n as Button, o as Panel, r as ConsoleShell, t as Badge } from "./panel-Bkw87EqF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/models-BKG-zByv.js
var import_jsx_runtime = require_jsx_runtime();
function ModelsPage() {
	const locale = useStudio((s) => s.locale);
	const query = useStudio((s) => s.query).trim().toLowerCase();
	const copy = t(locale);
	const list = MODELS.filter((m) => {
		if (!query) return true;
		const blurb = locale === "pt" ? m.blurbPt : m.blurbEn;
		return `${m.name} ${m.family} ${m.id} ${blurb}`.toLowerCase().includes(query);
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConsoleShell, {
		title: copy.modelsTitle,
		hint: copy.modelsHint,
		children: list.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
			className: "px-6 py-12 text-center text-sm text-muted",
			children: copy.noMatch
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-4 sm:grid-cols-2 xl:grid-cols-3",
			children: list.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "flex flex-col p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-base font-semibold",
							children: m.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-xs text-subtle",
							children: m.id
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: "accent",
							children: m.family
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 flex-1 text-sm leading-6 text-muted",
						children: locale === "pt" ? m.blurbPt : m.blurbEn
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-4 grid grid-cols-3 gap-2 text-xs text-subtle",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: copy.modality }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "font-medium text-fg",
								children: copy[m.modality]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: copy.context }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "font-medium text-fg tabular-nums",
								children: m.context
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: copy.rpm }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "font-medium text-fg tabular-nums",
								children: m.rpm
							})] })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 flex gap-2",
						children: m.chat ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							size: "sm",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/playground",
								children: copy.tryNow
							})
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							size: "sm",
							variant: "outline",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/docs",
								children: copy.apiRef
							})
						})
					})
				]
			}, m.id))
		})
	});
}
//#endregion
export { ModelsPage as component };
