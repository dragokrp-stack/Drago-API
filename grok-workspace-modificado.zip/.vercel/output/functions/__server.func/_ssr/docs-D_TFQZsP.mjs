import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { o as apiHost, s as regionLabel } from "./models-CJww7k-s.mjs";
import { _ as Copy, v as Check } from "../_libs/lucide-react.mjs";
import { _ as useStudio, c as cn, h as t, l as copyText, n as Button, o as Panel, r as ConsoleShell } from "./panel-Bkw87EqF.mjs";
import { t as useOrigin } from "./use-origin-BHbgPkVo.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/docs-D_TFQZsP.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CodeBlock({ code, label }) {
	const [done, setDone] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "overflow-hidden rounded-lg bg-code shadow-[var(--shadow-border)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between border-b border-border px-3 py-1.5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs text-subtle",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "iconSm",
				"aria-label": "Copy",
				onClick: async () => {
					await copyText(code);
					setDone(true);
					setTimeout(() => setDone(false), 1500);
				},
				children: done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {})
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
			className: cn("overflow-x-auto p-4 font-mono text-xs leading-6 text-fg"),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: code })
		})]
	});
}
function DocsPage() {
	const locale = useStudio((s) => s.locale);
	const regionId = useStudio((s) => s.regionId);
	const copy = t(locale);
	const origin = useOrigin();
	const host = origin ? apiHost(origin) : "https://<host>/api/v1";
	const [lang, setLang] = (0, import_react.useState)("curl");
	const curl = `curl ${host}/chat/completions \\
  -H "Authorization: Bearer $LUMEN_API_KEY" \\
  -H "Content-Type: application/json" \\
  -d '{
    "model": "lumen-max",
    "messages": [{"role":"user","content":"Olá"}]
  }'`;
	const py = `from openai import OpenAI

client = OpenAI(
    api_key="sk-lx-...",
    base_url="${host}",
)

r = client.chat.completions.create(
    model="lumen-max",
    messages=[{"role": "user", "content": "Olá"}],
)
print(r.choices[0].message.content)`;
	const js = `import OpenAI from "openai";

const client = new OpenAI({
  apiKey: process.env.LUMEN_API_KEY,
  baseURL: "${host}",
});

const r = await client.chat.completions.create({
  model: "lumen-max",
  messages: [{ role: "user", content: "Olá" }],
});
console.log(r.choices[0].message.content);`;
	const snippet = lang === "curl" ? curl : lang === "py" ? py : js;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ConsoleShell, {
		title: copy.docsTitle,
		hint: copy.docsHint,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
						className: "p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium text-subtle",
								children: copy.step1
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm leading-6 text-muted",
								children: copy.emptyBody
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								className: "mt-4",
								size: "sm",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/",
									children: copy.goCreate
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
						className: "p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium text-subtle",
								children: copy.step2
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 font-mono text-xs break-all",
								children: host
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-xs text-subtle",
								children: regionLabel(regionId, locale)
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
						className: "p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium text-subtle",
							children: copy.step3
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-6 text-muted",
							children: copy.allRegions
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 flex gap-1",
				children: [
					["curl", copy.exampleCurl],
					["py", copy.examplePy],
					["js", copy.exampleJs]
				].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setLang(id),
					className: cn("h-10 rounded-md px-3 text-sm", lang === id ? "bg-primary-soft font-medium text-primary" : "text-muted hover:text-fg"),
					children: label
				}, id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodeBlock, {
					code: snippet,
					label: lang === "curl" ? copy.exampleCurl : lang === "py" ? copy.examplePy : copy.exampleJs
				})
			})
		]
	});
}
//#endregion
export { DocsPage as component };
