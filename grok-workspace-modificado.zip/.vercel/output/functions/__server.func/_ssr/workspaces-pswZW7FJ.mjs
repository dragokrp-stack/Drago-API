import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { r as Trash2, s as Plus } from "../_libs/lucide-react.mjs";
import { _ as useStudio, d as formatDate, g as useHydrated, h as t, i as Input, n as Button, o as Panel, r as ConsoleShell } from "./panel-Bkw87EqF.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as DialogContent, t as Dialog } from "./dialog-CTCHyOEH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/workspaces-pswZW7FJ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function WorkspacesPage() {
	const locale = useStudio((s) => s.locale);
	const copy = t(locale);
	const hydrated = useHydrated();
	const workspaces = useStudio((s) => s.workspaces);
	const keys = useStudio((s) => s.keys);
	const query = useStudio((s) => s.query).trim().toLowerCase();
	const [open, setOpen] = (0, import_react.useState)(false);
	const [name, setName] = (0, import_react.useState)("");
	const list = workspaces.filter((w) => {
		if (!query) return true;
		return w.name.toLowerCase().includes(query) || w.id.toLowerCase().includes(query);
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ConsoleShell, {
		title: copy.wsTitle,
		hint: copy.wsHint,
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			onClick: () => setOpen(true),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), copy.wsCreate]
		}),
		children: [!hydrated ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, { className: "h-40 animate-pulse" }) : list.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
			className: "px-6 py-12 text-center text-sm text-muted",
			children: copy.noMatch
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-3",
			children: list.map((w) => {
				const count = keys.filter((k) => k.workspaceId === w.id).length;
				const isDefault = w.id === "ws-default";
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
					className: "flex flex-col gap-3 p-4 sm:flex-row sm:items-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium",
							children: isDefault ? copy.wsDefault : w.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-subtle",
							children: [
								w.id,
								" · ",
								formatDate(w.createdAt, locale),
								" · ",
								count,
								"/20"
							]
						})]
					}), !isDefault ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "dangerOutline",
						size: "sm",
						onClick: () => {
							if (!useStudio.getState().removeWorkspace(w.id).ok) toast.error(copy.wsInUse);
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {}), copy.wsDelete]
					}) : null]
				}, w.id);
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open,
			onOpenChange: setOpen,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
				title: copy.wsCreate,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block space-y-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs font-medium text-muted",
						children: copy.wsName
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: name,
						onChange: (e) => setName(e.target.value),
						maxLength: 40
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 flex justify-end gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: () => setOpen(false),
						children: copy.cancel
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => {
							if (!name.trim()) return;
							useStudio.getState().addWorkspace(name);
							setName("");
							setOpen(false);
						},
						children: copy.ok
					})]
				})]
			})
		})]
	});
}
//#endregion
export { WorkspacesPage as component };
