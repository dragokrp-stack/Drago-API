import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/use-origin-BHbgPkVo.js
var import_react = /* @__PURE__ */ __toESM(require_react());
function useOrigin() {
	const [origin, setOrigin] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		setOrigin(window.location.origin);
	}, []);
	return origin;
}
//#endregion
export { useOrigin as t };
