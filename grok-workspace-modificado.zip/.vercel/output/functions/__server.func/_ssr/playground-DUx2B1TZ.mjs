import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as createServerFn } from "./ssr.mjs";
import { r as MODELS, t as CHAT_MODELS } from "./models-CJww7k-s.mjs";
import { a as Send, i as Sparkles } from "../_libs/lucide-react.mjs";
import { _ as useStudio, a as NativeSelect, c as cn, g as useHydrated, h as t, n as Button, o as Panel, p as maskKey, r as ConsoleShell, s as Textarea } from "./panel-Bkw87EqF.mjs";
import { t as createSsrRpc } from "./createSsrRpc-C1p7zOu_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/playground-DUx2B1TZ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var completeChat = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("58260998c9cd54ce41b1aca7738021c1654c6659d23c7ce9547eebc567407f4f"));
function PlaygroundPage() {
	const locale = useStudio((s) => s.locale);
	const copy = t(locale);
	const hydrated = useHydrated();
	const regionId = useStudio((s) => s.regionId);
	const keys = useStudio((s) => s.keys);
	const liveKeys = (0, import_react.useMemo)(() => keys.filter((k) => k.regionId === regionId && k.status === "enabled" && (!k.expiresAt || k.expiresAt > Date.now())), [keys, regionId]);
	const [keyId, setKeyId] = (0, import_react.useState)("");
	const [modelId, setModelId] = (0, import_react.useState)(CHAT_MODELS[0]?.id ?? "lumen-max");
	const [prompt, setPrompt] = (0, import_react.useState)("");
	const [messages, setMessages] = (0, import_react.useState)([]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const selectedKey = liveKeys.find((k) => k.id === keyId) ?? liveKeys[0];
	const model = MODELS.find((m) => m.id === modelId);
	const allowed = !selectedKey || selectedKey.access === "all" ? CHAT_MODELS : CHAT_MODELS.filter((m) => selectedKey.allowedModels.includes(m.id));
	async function send() {
		if (!selectedKey || !prompt.trim() || busy) return;
		const user = {
			role: "user",
			content: prompt.trim()
		};
		const next = [...messages, user].slice(-12);
		setMessages(next);
		setPrompt("");
		setBusy(true);
		setError("");
		const result = await completeChat({ data: {
			key: selectedKey.secret,
			model: modelId,
			messages: next
		} });
		setBusy(false);
		if (!result.ok) {
			const map = {
				invalid_key: copy.errInvalidKey,
				rate_limited: copy.errRate,
				ai_unavailable: copy.errAi,
				bad_model: copy.errModel,
				bad_request: copy.errUp,
				upstream: copy.errUp
			};
			setError(map[result.code] ?? copy.errUp);
			return;
		}
		useStudio.getState().touchKey(selectedKey.id);
		useStudio.getState().addUsage(result.tokensIn, result.tokensOut);
		setMessages([...next, {
			role: "assistant",
			content: result.text
		}]);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConsoleShell, {
		title: copy.playgroundTitle,
		hint: copy.playgroundHint,
		children: !hydrated ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, { className: "h-96 animate-pulse bg-surface" }) : !liveKeys.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			className: "flex flex-col items-center px-6 py-16 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "mb-3 size-8 text-primary" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: copy.needKey
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "mt-4 inline-flex h-11 items-center rounded-md bg-primary px-4 text-sm font-medium text-primary-fg",
					children: copy.goCreate
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			className: "flex min-h-[32rem] flex-col",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-3 border-b border-border p-4 sm:flex-row sm:items-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "min-w-0 flex-1 space-y-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-medium text-muted",
								children: copy.selectModel
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NativeSelect, {
								value: allowed.some((m) => m.id === modelId) ? modelId : allowed[0]?.id ?? "",
								onChange: (e) => setModelId(e.target.value),
								children: allowed.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: m.id,
									children: m.name
								}, m.id))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "min-w-0 flex-1 space-y-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-medium text-muted",
								children: copy.selectKey
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NativeSelect, {
								value: selectedKey?.id ?? "",
								onChange: (e) => setKeyId(e.target.value),
								children: liveKeys.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
									value: k.id,
									children: [maskKey(k.secret), k.description ? ` · ${k.description}` : ""]
								}, k.id))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							className: "sm:mt-5",
							onClick: () => {
								setMessages([]);
								setError("");
							},
							children: copy.newChat
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-h-72 flex-1 flex-col gap-4 overflow-y-auto p-4",
					children: [
						messages.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "m-auto max-w-sm text-center text-sm text-subtle",
							children: model && !model.chat ? copy.noChat : copy.promptPh
						}) : messages.map((m, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: cn("max-w-2xl rounded-lg px-3 py-2 text-sm leading-6", {
								"ml-auto bg-primary-soft text-fg": m.role === "user",
								"bg-bg text-fg": m.role !== "user"
							}),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-1 text-xs font-medium text-subtle",
								children: m.role === "user" ? copy.you : copy.assistant
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "whitespace-pre-wrap",
								children: m.content
							})]
						}, `${m.role}-${i}`)),
						busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-subtle",
							children: copy.thinking
						}) : null,
						error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-danger",
							children: error
						}) : null
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "flex flex-col gap-2 border-t border-border p-3 sm:flex-row sm:items-end",
					onSubmit: (e) => {
						e.preventDefault();
						send();
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						value: prompt,
						onChange: (e) => setPrompt(e.target.value),
						placeholder: copy.promptPh,
						className: "min-h-16 flex-1",
						onKeyDown: (e) => {
							if (e.key === "Enter" && !e.shiftKey) {
								e.preventDefault();
								send();
							}
						}
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "submit",
						size: "lg",
						disabled: busy || !prompt.trim(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, {}), copy.send]
					})]
				})
			]
		})
	});
}
//#endregion
export { PlaygroundPage as component };
