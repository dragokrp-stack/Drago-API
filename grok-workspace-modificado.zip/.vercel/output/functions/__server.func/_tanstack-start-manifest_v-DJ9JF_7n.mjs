//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DJ9JF_7n.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/docs",
			"/models",
			"/playground",
			"/usage",
			"/workspaces",
			"/api/v1/models",
			"/api/v1/chat/completions"
		],
		preloads: ["/assets/index-Cr8atpKD.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Cr8atpKD.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-tGBK-_jL.js",
			"/assets/createServerFn-ytdqDI7Z.js",
			"/assets/panel-DbomCso1.js",
			"/assets/use-origin-DpHxKKdL.js",
			"/assets/dialog-4MdgDvzE.js"
		]
	},
	"/docs": {
		filePath: "/workspace/src/routes/docs.tsx",
		children: void 0,
		preloads: [
			"/assets/docs-B4VYHZQk.js",
			"/assets/panel-DbomCso1.js",
			"/assets/use-origin-DpHxKKdL.js"
		]
	},
	"/models": {
		filePath: "/workspace/src/routes/models.tsx",
		children: void 0,
		preloads: ["/assets/models-D5c1rs2M.js", "/assets/panel-DbomCso1.js"]
	},
	"/playground": {
		filePath: "/workspace/src/routes/playground.tsx",
		children: void 0,
		preloads: [
			"/assets/playground-McwFXHQ6.js",
			"/assets/createServerFn-ytdqDI7Z.js",
			"/assets/panel-DbomCso1.js"
		]
	},
	"/usage": {
		filePath: "/workspace/src/routes/usage.tsx",
		children: void 0,
		preloads: ["/assets/usage-DLlkJJzj.js", "/assets/panel-DbomCso1.js"]
	},
	"/workspaces": {
		filePath: "/workspace/src/routes/workspaces.tsx",
		children: void 0,
		preloads: [
			"/assets/workspaces-CaJplL5f.js",
			"/assets/panel-DbomCso1.js",
			"/assets/dialog-4MdgDvzE.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
