import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ConsoleShell } from "@/components/console-shell";
import { CodeBlock } from "@/components/code-block";
import { Button } from "@/components/ui/button";
import { Panel } from "@/components/ui/panel";
import { useOrigin } from "@/hooks/use-origin";
import { t } from "@/lib/i18n";
import { apiHost, regionLabel } from "@/lib/models";
import { useStudio } from "@/lib/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/docs")({ component: DocsPage });

function DocsPage() {
  const locale = useStudio((s) => s.locale);
  const regionId = useStudio((s) => s.regionId);
  const copy = t(locale);
  const origin = useOrigin();
  const host = origin ? apiHost(origin) : "https://<host>/api/v1";
  const [lang, setLang] = useState<"curl" | "py" | "js">("curl");

  const curl = `curl ${host}/chat/completions \\
  -H "Authorization: Bearer $LUMEN_API_KEY" \\
  -H "Content-Type: application/json" \\
  -d '{
    "model": "lumen-max",
    "messages": [{"role":"user","content":"Olá"}]
  }'`;

  const py = `from openai import OpenAI

client = OpenAI(
    api_key="sk-lx-...",
    base_url="${host}",
)

r = client.chat.completions.create(
    model="lumen-max",
    messages=[{"role": "user", "content": "Olá"}],
)
print(r.choices[0].message.content)`;

  const js = `import OpenAI from "openai";

const client = new OpenAI({
  apiKey: process.env.LUMEN_API_KEY,
  baseURL: "${host}",
});

const r = await client.chat.completions.create({
  model: "lumen-max",
  messages: [{ role: "user", content: "Olá" }],
});
console.log(r.choices[0].message.content);`;

  const snippet = lang === "curl" ? curl : lang === "py" ? py : js;

  return (
    <ConsoleShell title={copy.docsTitle} hint={copy.docsHint}>
      <div className="grid gap-4 lg:grid-cols-3">
        <Panel className="p-5">
          <p className="text-xs font-medium text-subtle">{copy.step1}</p>
          <p className="mt-2 text-sm leading-6 text-muted">{copy.emptyBody}</p>
          <Button asChild className="mt-4" size="sm">
            <Link to="/">{copy.goCreate}</Link>
          </Button>
        </Panel>
        <Panel className="p-5">
          <p className="text-xs font-medium text-subtle">{copy.step2}</p>
          <p className="mt-2 font-mono text-xs break-all">{host}</p>
          <p className="mt-2 text-xs text-subtle">{regionLabel(regionId, locale)}</p>
        </Panel>
        <Panel className="p-5">
          <p className="text-xs font-medium text-subtle">{copy.step3}</p>
          <p className="mt-2 text-sm leading-6 text-muted">{copy.allRegions}</p>
        </Panel>
      </div>

      <div className="mt-6 flex gap-1">
        {(
          [
            ["curl", copy.exampleCurl],
            ["py", copy.examplePy],
            ["js", copy.exampleJs],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            onClick={() => setLang(id)}
            className={cn(
              "h-10 rounded-md px-3 text-sm",
              lang === id ? "bg-primary-soft font-medium text-primary" : "text-muted hover:text-fg",
            )}
          >
            {label}
          </button>
        ))}
      </div>
      <div className="mt-3">
        <CodeBlock
          code={snippet}
          label={lang === "curl" ? copy.exampleCurl : lang === "py" ? copy.examplePy : copy.exampleJs}
        />
      </div>
    </ConsoleShell>
  );
}
