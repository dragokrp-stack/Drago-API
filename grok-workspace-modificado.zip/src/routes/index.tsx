import { createFileRoute } from "@tanstack/react-router";
import { ConsoleShell } from "@/components/console-shell";
import { KeysManager } from "@/components/keys-manager";
import { t } from "@/lib/i18n";
import { useStudio } from "@/lib/store";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const locale = useStudio((s) => s.locale);
  const copy = t(locale);
  return (
    <ConsoleShell title={copy.apiTitle} hint={copy.apiHint}>
      <KeysManager />
    </ConsoleShell>
  );
}
