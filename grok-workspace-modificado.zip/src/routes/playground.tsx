import { useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Send, Sparkles } from "lucide-react";
import { ConsoleShell } from "@/components/console-shell";
import { Button } from "@/components/ui/button";
import { NativeSelect, Textarea } from "@/components/ui/input";
import { Panel } from "@/components/ui/panel";
import { completeChat } from "@/lib/chat";
import { t } from "@/lib/i18n";
import { CHAT_MODELS, MODELS } from "@/lib/models";
import { useHydrated, useStudio } from "@/lib/store";
import type { ChatMessage } from "@/lib/types";
import { maskKey } from "@/lib/utils";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/playground")({ component: PlaygroundPage });

function PlaygroundPage() {
  const locale = useStudio((s) => s.locale);
  const copy = t(locale);
  const hydrated = useHydrated();
  const regionId = useStudio((s) => s.regionId);
  const keys = useStudio((s) => s.keys);
  const liveKeys = useMemo(
    () =>
      keys.filter(
        (k) =>
          k.regionId === regionId &&
          k.status === "enabled" &&
          (!k.expiresAt || k.expiresAt > Date.now()),
      ),
    [keys, regionId],
  );

  const [keyId, setKeyId] = useState("");
  const [modelId, setModelId] = useState(CHAT_MODELS[0]?.id ?? "lumen-max");
  const [prompt, setPrompt] = useState("");
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const selectedKey = liveKeys.find((k) => k.id === keyId) ?? liveKeys[0];
  const model = MODELS.find((m) => m.id === modelId);
  const allowed =
    !selectedKey || selectedKey.access === "all"
      ? CHAT_MODELS
      : CHAT_MODELS.filter((m) => selectedKey.allowedModels.includes(m.id));

  async function send() {
    if (!selectedKey || !prompt.trim() || busy) return;
    const user: ChatMessage = { role: "user", content: prompt.trim() };
    const next = [...messages, user].slice(-12);
    setMessages(next);
    setPrompt("");
    setBusy(true);
    setError("");
    const result = await completeChat({
      data: {
        key: selectedKey.secret,
        model: modelId,
        messages: next,
      },
    });
    setBusy(false);
    if (!result.ok) {
      const map = {
        invalid_key: copy.errInvalidKey,
        rate_limited: copy.errRate,
        ai_unavailable: copy.errAi,
        bad_model: copy.errModel,
        bad_request: copy.errUp,
        upstream: copy.errUp,
      } as const;
      setError(map[result.code] ?? copy.errUp);
      return;
    }
    useStudio.getState().touchKey(selectedKey.id);
    useStudio.getState().addUsage(result.tokensIn, result.tokensOut);
    setMessages([...next, { role: "assistant", content: result.text }]);
  }

  return (
    <ConsoleShell title={copy.playgroundTitle} hint={copy.playgroundHint}>
      {!hydrated ? (
        <Panel className="h-96 animate-pulse bg-surface" />
      ) : !liveKeys.length ? (
        <Panel className="flex flex-col items-center px-6 py-16 text-center">
          <Sparkles className="mb-3 size-8 text-primary" />
          <p className="text-sm text-muted">{copy.needKey}</p>
          <Link
            to="/"
            className="mt-4 inline-flex h-11 items-center rounded-md bg-primary px-4 text-sm font-medium text-primary-fg"
          >
            {copy.goCreate}
          </Link>
        </Panel>
      ) : (
        <Panel className="flex min-h-[32rem] flex-col">
          <div className="flex flex-col gap-3 border-b border-border p-4 sm:flex-row sm:items-center">
            <label className="min-w-0 flex-1 space-y-1">
              <span className="text-xs font-medium text-muted">{copy.selectModel}</span>
              <NativeSelect
                value={allowed.some((m) => m.id === modelId) ? modelId : (allowed[0]?.id ?? "")}
                onChange={(e) => setModelId(e.target.value)}
              >
                {allowed.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.name}
                  </option>
                ))}
              </NativeSelect>
            </label>
            <label className="min-w-0 flex-1 space-y-1">
              <span className="text-xs font-medium text-muted">{copy.selectKey}</span>
              <NativeSelect
                value={selectedKey?.id ?? ""}
                onChange={(e) => setKeyId(e.target.value)}
              >
                {liveKeys.map((k) => (
                  <option key={k.id} value={k.id}>
                    {maskKey(k.secret)}
                    {k.description ? ` · ${k.description}` : ""}
                  </option>
                ))}
              </NativeSelect>
            </label>
            <Button
              variant="outline"
              className="sm:mt-5"
              onClick={() => {
                setMessages([]);
                setError("");
              }}
            >
              {copy.newChat}
            </Button>
          </div>

          <div className="flex min-h-72 flex-1 flex-col gap-4 overflow-y-auto p-4">
            {messages.length === 0 ? (
              <p className="m-auto max-w-sm text-center text-sm text-subtle">
                {model && !model.chat ? copy.noChat : copy.promptPh}
              </p>
            ) : (
              messages.map((m, i) => (
                <div
                  key={`${m.role}-${i}`}
                  className={cn("max-w-2xl rounded-lg px-3 py-2 text-sm leading-6", {
                    "ml-auto bg-primary-soft text-fg": m.role === "user",
                    "bg-bg text-fg": m.role !== "user",
                  })}
                >
                  <p className="mb-1 text-xs font-medium text-subtle">
                    {m.role === "user" ? copy.you : copy.assistant}
                  </p>
                  <p className="whitespace-pre-wrap">{m.content}</p>
                </div>
              ))
            )}
            {busy ? <p className="text-sm text-subtle">{copy.thinking}</p> : null}
            {error ? <p className="text-sm text-danger">{error}</p> : null}
          </div>

          <form
            className="flex flex-col gap-2 border-t border-border p-3 sm:flex-row sm:items-end"
            onSubmit={(e) => {
              e.preventDefault();
              void send();
            }}
          >
            <Textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder={copy.promptPh}
              className="min-h-16 flex-1"
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  void send();
                }
              }}
            />
            <Button type="submit" size="lg" disabled={busy || !prompt.trim()}>
              <Send />
              {copy.send}
            </Button>
          </form>
        </Panel>
      )}
    </ConsoleShell>
  );
}
