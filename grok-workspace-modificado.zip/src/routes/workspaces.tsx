import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Plus, Trash2 } from "lucide-react";
import { ConsoleShell } from "@/components/console-shell";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Panel } from "@/components/ui/panel";
import { t } from "@/lib/i18n";
import { useHydrated, useStudio } from "@/lib/store";
import { formatDate } from "@/lib/utils";
import { toast } from "sonner";

export const Route = createFileRoute("/workspaces")({ component: WorkspacesPage });

function WorkspacesPage() {
  const locale = useStudio((s) => s.locale);
  const copy = t(locale);
  const hydrated = useHydrated();
  const workspaces = useStudio((s) => s.workspaces);
  const keys = useStudio((s) => s.keys);
  const query = useStudio((s) => s.query).trim().toLowerCase();
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");

  const list = workspaces.filter((w) => {
    if (!query) return true;
    return w.name.toLowerCase().includes(query) || w.id.toLowerCase().includes(query);
  });

  return (
    <ConsoleShell
      title={copy.wsTitle}
      hint={copy.wsHint}
      actions={
        <Button onClick={() => setOpen(true)}>
          <Plus />
          {copy.wsCreate}
        </Button>
      }
    >
      {!hydrated ? (
        <Panel className="h-40 animate-pulse" />
      ) : list.length === 0 ? (
        <Panel className="px-6 py-12 text-center text-sm text-muted">{copy.noMatch}</Panel>
      ) : (
        <div className="grid gap-3">
          {list.map((w) => {
            const count = keys.filter((k) => k.workspaceId === w.id).length;
            const isDefault = w.id === "ws-default";
            return (
              <Panel key={w.id} className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center">
                <div className="min-w-0 flex-1">
                  <p className="font-medium">{isDefault ? copy.wsDefault : w.name}</p>
                  <p className="text-xs text-subtle">
                    {w.id} · {formatDate(w.createdAt, locale)} · {count}/20
                  </p>
                </div>
                {!isDefault ? (
                  <Button
                    variant="dangerOutline"
                    size="sm"
                    onClick={() => {
                      const result = useStudio.getState().removeWorkspace(w.id);
                      if (!result.ok) toast.error(copy.wsInUse);
                    }}
                  >
                    <Trash2 />
                    {copy.wsDelete}
                  </Button>
                ) : null}
              </Panel>
            );
          })}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent title={copy.wsCreate}>
          <label className="block space-y-1.5">
            <span className="text-xs font-medium text-muted">{copy.wsName}</span>
            <Input value={name} onChange={(e) => setName(e.target.value)} maxLength={40} />
          </label>
          <div className="mt-5 flex justify-end gap-2">
            <Button variant="outline" onClick={() => setOpen(false)}>
              {copy.cancel}
            </Button>
            <Button
              onClick={() => {
                if (!name.trim()) return;
                useStudio.getState().addWorkspace(name);
                setName("");
                setOpen(false);
              }}
            >
              {copy.ok}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </ConsoleShell>
  );
}
