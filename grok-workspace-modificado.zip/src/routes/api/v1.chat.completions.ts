import type { ChatTurn } from "@/lib/complete.server";
import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/v1/chat/completions")({
  server: {
    handlers: {
      OPTIONS: async () => {
        const { CORS } = await import("@/lib/complete.server");
        return new Response(null, { status: 204, headers: CORS });
      },
      POST: async ({ request }) => {
        const { complete, bearerKey, CORS } = await import("@/lib/complete.server");
        const jsonHeaders = { ...CORS, "Content-Type": "application/json" };
        let body: {
          model?: string;
          messages?: { role: string; content: unknown }[];
        };
        try {
          body = (await request.json()) as typeof body;
        } catch {
          return Response.json(
            { error: { message: "Invalid JSON body." } },
            { status: 400, headers: jsonHeaders },
          );
        }
        const result = await complete({
          key: bearerKey(request),
          model: body.model ?? "",
          messages: Array.isArray(body.messages) ? (body.messages as ChatTurn[]) : [],
        });
        if (!result.ok) {
          return Response.json(
            { error: { message: result.message, type: result.code } },
            {
              status: result.status,
              headers: {
                ...jsonHeaders,
                ...(result.retryAfter ? { "Retry-After": String(result.retryAfter) } : {}),
              },
            },
          );
        }
        return Response.json(
          {
            id: `chatcmpl-${Date.now().toString(36)}`,
            object: "chat.completion",
            created: Math.floor(Date.now() / 1000),
            model: result.model,
            choices: [
              {
                index: 0,
                message: { role: "assistant", content: result.text },
                finish_reason: "stop",
              },
            ],
            usage: {
              prompt_tokens: result.tokensIn,
              completion_tokens: result.tokensOut,
              total_tokens: result.tokensIn + result.tokensOut,
            },
          },
          { headers: jsonHeaders },
        );
      },
    },
  },
});
