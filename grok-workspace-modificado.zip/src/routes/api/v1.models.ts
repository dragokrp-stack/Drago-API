import { createFileRoute } from "@tanstack/react-router";
import { MODELS } from "@/lib/models";

export const Route = createFileRoute("/api/v1/models")({
  server: {
    handlers: {
      OPTIONS: async () => {
        const { CORS } = await import("@/lib/complete.server");
        return new Response(null, { status: 204, headers: CORS });
      },
      GET: async () => {
        const { CORS } = await import("@/lib/complete.server");
        return Response.json(
          {
            object: "list",
            data: MODELS.map((m) => ({
              id: m.id,
              object: "model",
              created: 0,
              owned_by: "lumen-studio",
              family: m.family,
              modality: m.modality,
            })),
          },
          { headers: { ...CORS, "Content-Type": "application/json" } },
        );
      },
    },
  },
});
