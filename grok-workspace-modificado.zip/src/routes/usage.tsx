import { createFileRoute } from "@tanstack/react-router";
import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { ConsoleShell } from "@/components/console-shell";
import { Panel } from "@/components/ui/panel";
import { t } from "@/lib/i18n";
import { FREE_TOKEN_QUOTA } from "@/lib/models";
import { useHydrated, useStudio } from "@/lib/store";
import { formatNumber } from "@/lib/utils";

export const Route = createFileRoute("/usage")({ component: UsagePage });

function UsagePage() {
  const locale = useStudio((s) => s.locale);
  const copy = t(locale);
  const hydrated = useHydrated();
  const usage = useStudio((s) => s.usage);
  const used = (usage.tokensIn ?? 0) + (usage.tokensOut ?? 0);
  const remaining = Math.max(0, FREE_TOKEN_QUOTA - used);
  const pct = Math.min(100, Math.round((used / FREE_TOKEN_QUOTA) * 100));
  const daily = Array.isArray(usage.daily) ? usage.daily : [];

  return (
    <ConsoleShell title={copy.usageTitle} hint={copy.usageHint}>
      {!hydrated ? (
        <div className="grid gap-4 sm:grid-cols-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <Panel key={i} className="h-28 animate-pulse" />
          ))}
        </div>
      ) : (
        <>
          <div className="mb-4 rounded-lg bg-primary-soft px-4 py-3 text-sm">{copy.neverPay}</div>
          <div className="grid gap-4 sm:grid-cols-3">
            <Stat label={copy.quota} value={formatNumber(FREE_TOKEN_QUOTA, locale)} hint="tokens" />
            <Stat label={copy.tokensUsed} value={formatNumber(used, locale)} hint={`${pct}% ${copy.used}`} />
            <Stat
              label={copy.remaining}
              value={formatNumber(remaining, locale)}
              hint={`${formatNumber(usage.requests, locale)} ${copy.requests.toLowerCase()}`}
            />
          </div>
          <Panel className="mt-4 p-5">
            <div className="mb-3 flex items-center justify-between gap-3">
              <p className="text-sm font-medium">{copy.quotaBar}</p>
              <p className="text-xs text-muted tabular-nums">{pct}%</p>
            </div>
            <div className="h-2 overflow-hidden rounded-full bg-bg">
              <div
                className="h-full rounded-full bg-primary transition-[width] duration-(--motion-fast) ease-(--ease-out)"
                style={{ width: `${pct}%` }}
              />
            </div>
            <dl className="mt-4 grid grid-cols-2 gap-3 text-sm">
              <div>
                <dt className="text-xs text-subtle">{copy.tokensIn}</dt>
                <dd className="font-medium tabular-nums">{formatNumber(usage.tokensIn ?? 0, locale)}</dd>
              </div>
              <div>
                <dt className="text-xs text-subtle">{copy.tokensOut}</dt>
                <dd className="font-medium tabular-nums">{formatNumber(usage.tokensOut ?? 0, locale)}</dd>
              </div>
            </dl>
          </Panel>
          <Panel className="mt-4 p-5">
            <p className="mb-4 text-sm font-medium">{copy.last14}</p>
            {daily.length === 0 ? (
              <p className="py-10 text-center text-sm text-subtle">{copy.never}</p>
            ) : (
              <div className="h-56">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={daily}>
                    <XAxis dataKey="day" tick={{ fontSize: 11 }} stroke="var(--color-subtle)" />
                    <YAxis tick={{ fontSize: 11 }} stroke="var(--color-subtle)" />
                    <Tooltip
                      contentStyle={{
                        background: "var(--color-surface)",
                        border: "1px solid var(--color-border)",
                        borderRadius: 8,
                        fontSize: 12,
                      }}
                    />
                    <Area
                      type="monotone"
                      dataKey="tokens"
                      stroke="var(--color-primary)"
                      fill="var(--color-primary-soft)"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            )}
          </Panel>
        </>
      )}
    </ConsoleShell>
  );
}

function Stat({ label, value, hint }: { label: string; value: string; hint: string }) {
  return (
    <Panel className="p-5">
      <p className="text-xs font-medium text-muted">{label}</p>
      <p className="mt-2 text-2xl font-semibold tracking-tight tabular-nums">{value}</p>
      <p className="mt-1 text-xs text-subtle">{hint}</p>
    </Panel>
  );
}
