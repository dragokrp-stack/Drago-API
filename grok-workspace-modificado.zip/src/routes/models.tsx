import { createFileRoute, Link } from "@tanstack/react-router";
import { ConsoleShell } from "@/components/console-shell";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Panel } from "@/components/ui/panel";
import { t } from "@/lib/i18n";
import { MODELS } from "@/lib/models";
import { useStudio } from "@/lib/store";

export const Route = createFileRoute("/models")({ component: ModelsPage });

function ModelsPage() {
  const locale = useStudio((s) => s.locale);
  const query = useStudio((s) => s.query).trim().toLowerCase();
  const copy = t(locale);
  const list = MODELS.filter((m) => {
    if (!query) return true;
    const blurb = locale === "pt" ? m.blurbPt : m.blurbEn;
    return `${m.name} ${m.family} ${m.id} ${blurb}`.toLowerCase().includes(query);
  });

  return (
    <ConsoleShell title={copy.modelsTitle} hint={copy.modelsHint}>
      {list.length === 0 ? (
        <Panel className="px-6 py-12 text-center text-sm text-muted">{copy.noMatch}</Panel>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {list.map((m) => (
            <Panel key={m.id} className="flex flex-col p-5">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <h2 className="text-base font-semibold">{m.name}</h2>
                  <p className="font-mono text-xs text-subtle">{m.id}</p>
                </div>
                <Badge tone="accent">{m.family}</Badge>
              </div>
              <p className="mt-3 flex-1 text-sm leading-6 text-muted">
                {locale === "pt" ? m.blurbPt : m.blurbEn}
              </p>
              <dl className="mt-4 grid grid-cols-3 gap-2 text-xs text-subtle">
                <div>
                  <dt>{copy.modality}</dt>
                  <dd className="font-medium text-fg">{copy[m.modality]}</dd>
                </div>
                <div>
                  <dt>{copy.context}</dt>
                  <dd className="font-medium text-fg tabular-nums">{m.context}</dd>
                </div>
                <div>
                  <dt>{copy.rpm}</dt>
                  <dd className="font-medium text-fg tabular-nums">{m.rpm}</dd>
                </div>
              </dl>
              <div className="mt-4 flex gap-2">
                {m.chat ? (
                  <Button asChild size="sm">
                    <Link to="/playground">{copy.tryNow}</Link>
                  </Button>
                ) : (
                  <Button asChild size="sm" variant="outline">
                    <Link to="/docs">{copy.apiRef}</Link>
                  </Button>
                )}
              </div>
            </Panel>
          ))}
        </div>
      )}
    </ConsoleShell>
  );
}
