import { createHmac, randomBytes, timingSafeEqual } from "node:crypto";

const PREFIX = "sk-lx-";
const ID_LEN = 32;
const SIG_LEN = 16;

function signingSecret() {
  // Keep the xAI credential separate from the signing secret. The fallback
  // preserves compatibility with older deployments, but new deployments
  // should always set XAI_SIGNING_SECRET.
  return process.env.XAI_SIGNING_SECRET?.trim() || process.env.XAI_API_KEY?.trim() || "";
}

export function issueSignedKey() {
  const secret = signingSecret();
  if (!secret) throw new Error("XAI_SIGNING_SECRET is not configured.");

  const id = randomBytes(ID_LEN / 2).toString("hex");
  const sig = createHmac("sha256", secret).update(id).digest("hex").slice(0, SIG_LEN);
  return { id, key: `${PREFIX}${id}${sig}`, issuedAt: Date.now() };
}

export function verifySignedKey(key: string) {
  const secret = signingSecret();
  const expectedLen = PREFIX.length + ID_LEN + SIG_LEN;
  if (!secret || typeof key !== "string" || key.length !== expectedLen) return null;
  if (!key.startsWith(PREFIX)) return null;
  const id = key.slice(PREFIX.length, PREFIX.length + ID_LEN);
  const sig = key.slice(PREFIX.length + ID_LEN);
  if (!/^[0-9a-f]+$/.test(id) || !/^[0-9a-f]+$/.test(sig)) return null;
  const expected = createHmac("sha256", secret).update(id).digest("hex").slice(0, SIG_LEN);
  const a = Buffer.from(sig);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
  return { id, key };
}

const buckets = new Map<string, { count: number; resetAt: number }>();
const WINDOW_MS = 60 * 60 * 1000;
const MAX_PER_WINDOW = Math.max(1, Number(process.env.RATE_LIMIT_PER_HOUR ?? 40));

export function rateLimit(id: string) {
  const now = Date.now();
  const current = buckets.get(id);
  if (!current || now > current.resetAt) {
    buckets.set(id, { count: 1, resetAt: now + WINDOW_MS });
    return { ok: true as const, remaining: MAX_PER_WINDOW - 1, resetAt: now + WINDOW_MS };
  }
  if (current.count >= MAX_PER_WINDOW) {
    return { ok: false as const, retryAt: current.resetAt };
  }
  current.count += 1;
  return { ok: true as const, remaining: MAX_PER_WINDOW - current.count, resetAt: current.resetAt };
}
