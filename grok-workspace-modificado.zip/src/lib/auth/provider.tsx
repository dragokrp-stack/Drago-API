import type { ReactNode } from "react";
import { Toaster } from "sonner";

/**
 * App-wide client provider mounted once near the top of `__root.tsx`.
 */
export function AuthProvider({ children }: { children: ReactNode }) {
  return (
    <>
      {children}
      <Toaster
        position="top-center"
        toastOptions={{
          className: "font-sans !bg-surface !text-fg !shadow-[var(--shadow-modal)]",
        }}
      />
    </>
  );
}
