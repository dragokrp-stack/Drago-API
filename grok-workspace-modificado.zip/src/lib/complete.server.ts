import { verifySignedKey, rateLimit } from "./api-keys.server";
import { MODEL_RUNTIME } from "./models";

export const CORS = {
  "Access-Control-Allow-Origin": process.env.CORS_ORIGIN?.trim() || "*",
  "Access-Control-Allow-Headers": "Authorization, Content-Type",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
};

export type ChatContentPart =
  | { type: "text"; text: string }
  | { type: "image_url"; image_url: { url: string; detail?: "auto" | "low" | "high" } };
export type ChatContent = string | ChatContentPart[];
export type ChatTurn = { role: string; content: ChatContent };

export type CompleteOk = {
  ok: true;
  text: string;
  tokensIn: number;
  tokensOut: number;
  model: string;
};

export type CompleteErr = {
  ok: false;
  code: "invalid_key" | "rate_limited" | "ai_unavailable" | "bad_model" | "bad_request" | "upstream";
  message: string;
  status: number;
  retryAfter?: number;
};

const MAX_MESSAGES = Math.max(1, Number(process.env.MAX_MESSAGES ?? 20));
const MAX_CONTENT = Math.max(256, Number(process.env.MAX_CONTENT_CHARS ?? 12000));

function sanitizeContent(content: ChatContent): ChatContent | null {
  if (typeof content === "string") {
    const value = content.trim();
    return value ? value.slice(0, MAX_CONTENT) : null;
  }
  if (Array.isArray(content)) {
    const parts = content.slice(0, 24).flatMap((part) => {
      if (!part || typeof part !== "object") return [];
      if (part.type === "text" && typeof part.text === "string") {
        const text = part.text.trim();
        return text ? [{ type: "text" as const, text: text.slice(0, MAX_CONTENT) }] : [];
      }
      if (
        part.type === "image_url" &&
        part.image_url &&
        typeof part.image_url.url === "string" &&
        part.image_url.url.length <= 12_000_000
      ) {
        return [part];
      }
      return [];
    });
    return parts.length ? parts : null;
  }
  return null;
}

function sanitizeMessages(messages: ChatTurn[]) {
  const allowed = new Set(["system", "user", "assistant"]);
  const next: { role: "system" | "user" | "assistant"; content: ChatContent }[] = [];
  for (const m of messages) {
    if (!m || !allowed.has(m.role)) continue;
    const content = sanitizeContent(m.content);
    if (!content) continue;
    next.push({ role: m.role as "system" | "user" | "assistant", content });
    if (next.length >= MAX_MESSAGES) break;
  }
  return next;
}

export async function complete(opts: {
  key: string;
  model: string;
  messages: ChatTurn[];
}): Promise<CompleteOk | CompleteErr> {
  const verified = verifySignedKey(opts.key);
  if (!verified) {
    return { ok: false, code: "invalid_key", message: "Invalid API key.", status: 401 };
  }

  const runtime = MODEL_RUNTIME[opts.model];
  if (!runtime) {
    return { ok: false, code: "bad_model", message: "Unknown or non-chat model.", status: 400 };
  }

  const messages = sanitizeMessages(opts.messages);
  if (!messages.length || messages[messages.length - 1]?.role !== "user") {
    return { ok: false, code: "bad_request", message: "Provide messages ending with a user turn.", status: 400 };
  }

  const rl = rateLimit(verified.id);
  if (!rl.ok) {
    return {
      ok: false,
      code: "rate_limited",
      message: "Rate limit reached. Try again later.",
      status: 429,
      retryAfter: Math.max(1, Math.ceil((rl.retryAt - Date.now()) / 1000)),
    };
  }

  const apiKey = process.env.XAI_API_KEY?.trim();
  if (!apiKey) {
    return { ok: false, code: "ai_unavailable", message: "Model service is not configured.", status: 503 };
  }

  const baseUrl = (process.env.XAI_BASE_URL?.trim() || "https://api.x.ai/v1").replace(/\/$/, "");
  const timeoutMs = Math.max(5_000, Number(process.env.XAI_TIMEOUT_MS ?? 45_000));
  let res: Response;
  try {
    res = await fetch(`${baseUrl}/chat/completions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: runtime.xai,
        messages,
        max_tokens: runtime.maxTokens,
        temperature: 0.7,
      }),
      signal: AbortSignal.timeout(timeoutMs),
    });
  } catch {
    return { ok: false, code: "upstream", message: "Upstream timeout or network error.", status: 504 };
  }

  if (!res.ok) {
    const retryAfterHeader = res.headers.get("retry-after");
    const retryAfter = retryAfterHeader ? Number(retryAfterHeader) : undefined;
    let providerMessage = `Model provider error ${res.status}.`;
    try {
      const errorBody = (await res.json()) as { error?: { message?: string } | string };
      const candidate = typeof errorBody.error === "string" ? errorBody.error : errorBody.error?.message;
      if (candidate) providerMessage = String(candidate).slice(0, 500);
    } catch {
      // Keep the stable status-based message if the provider returned non-JSON.
    }
    return {
      ok: false,
      code: "upstream",
      message: providerMessage,
      status: 502,
      ...(Number.isFinite(retryAfter) ? { retryAfter } : {}),
    };
  }

  const body = (await res.json()) as {
    choices?: { message?: { content?: string | unknown[] } }[];
    usage?: { prompt_tokens?: number; completion_tokens?: number };
  };
  const rawText = body.choices?.[0]?.message?.content;
  const text = typeof rawText === "string" ? rawText : JSON.stringify(rawText ?? "");
  return {
    ok: true,
    text,
    tokensIn: body.usage?.prompt_tokens ?? 0,
    tokensOut: body.usage?.completion_tokens ?? 0,
    model: opts.model,
  };
}

export function bearerKey(request: Request) {
  const header = request.headers.get("authorization") ?? "";
  const match = header.match(/^Bearer\s+(.+)$/i);
  return match?.[1]?.trim() ?? "";
}
