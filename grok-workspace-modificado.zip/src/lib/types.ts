export type Locale = "pt" | "en";

export type KeyStatus = "enabled" | "disabled";
export type AccessScope = "all" | "custom";
export type KeyKind = "standard" | "temporary";

export type Workspace = {
  id: string;
  name: string;
  createdAt: number;
};

export type ApiKeyRecord = {
  id: string;
  secret: string;
  kind: KeyKind;
  description: string;
  workspaceId: string;
  regionId: string;
  status: KeyStatus;
  access: AccessScope;
  ipWhitelist: string;
  allowedModels: string[];
  createdAt: number;
  expiresAt: number | null;
  lastUsedAt: number | null;
};

export type DailyPoint = {
  day: string;
  requests: number;
  tokens: number;
};

export type UsageStats = {
  requests: number;
  tokensIn: number;
  tokensOut: number;
  daily: DailyPoint[];
};

export type ChatMessage = {
  role: "user" | "assistant" | "system";
  content: string;
};
