import { createServerFn } from "@tanstack/react-start";

export const issueApiKey = createServerFn({ method: "POST" }).handler(async () => {
  const { issueSignedKey } = await import("./api-keys.server");
  try {
    return issueSignedKey();
  } catch {
    throw new Error("API key service is not configured. Set XAI_SIGNING_SECRET on the server.");
  }
});
