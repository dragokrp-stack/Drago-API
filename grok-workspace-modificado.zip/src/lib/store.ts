import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { ApiKeyRecord, KeyKind, Locale, UsageStats, Workspace } from "./types";

const DEFAULT_WS: Workspace = {
  id: "ws-default",
  name: "default",
  createdAt: Date.now(),
};

const EMPTY_USAGE: UsageStats = {
  requests: 0,
  tokensIn: 0,
  tokensOut: 0,
  daily: [],
};

type StudioState = {
  locale: Locale;
  regionId: string;
  hydrated: boolean;
  query: string;
  workspaces: Workspace[];
  keys: ApiKeyRecord[];
  usage: UsageStats;
  setLocale: (locale: Locale) => void;
  setRegion: (regionId: string) => void;
  setQuery: (query: string) => void;
  setHydrated: (v: boolean) => void;
  addWorkspace: (name: string) => string;
  renameWorkspace: (id: string, name: string) => void;
  removeWorkspace: (id: string) => { ok: true } | { ok: false; reason: "default" | "in_use" };
  addKey: (key: ApiKeyRecord) => { ok: true } | { ok: false; reason: "limit" };
  updateKey: (id: string, patch: Partial<ApiKeyRecord>) => void;
  removeKey: (id: string) => void;
  touchKey: (id: string) => void;
  addUsage: (tokensIn: number, tokensOut: number) => void;
};

function todayKey() {
  return new Date().toISOString().slice(0, 10);
}

export const useStudio = create<StudioState>()(
  persist(
    (set, get) => ({
      locale: "pt",
      regionId: "sa-east-1",
      hydrated: false,
      query: "",
      workspaces: [DEFAULT_WS],
      keys: [],
      usage: EMPTY_USAGE,
      setLocale: (locale) => set({ locale }),
      setRegion: (regionId) => set({ regionId, query: "" }),
      setQuery: (query) => set({ query }),
      setHydrated: (hydrated) => set({ hydrated }),
      addWorkspace: (name) => {
        const id = `ws-${crypto.randomUUID().slice(0, 8)}`;
        set({
          workspaces: [
            ...get().workspaces,
            { id, name: name.trim() || "workspace", createdAt: Date.now() },
          ],
        });
        return id;
      },
      renameWorkspace: (id, name) =>
        set({
          workspaces: get().workspaces.map((w) =>
            w.id === id ? { ...w, name: name.trim() || w.name } : w,
          ),
        }),
      removeWorkspace: (id) => {
        if (id === "ws-default") return { ok: false as const, reason: "default" as const };
        if (get().keys.some((k) => k.workspaceId === id)) {
          return { ok: false as const, reason: "in_use" as const };
        }
        set({ workspaces: get().workspaces.filter((w) => w.id !== id) });
        return { ok: true as const };
      },
      addKey: (key) => {
        const count = get().keys.filter(
          (k) => k.workspaceId === key.workspaceId && k.regionId === key.regionId,
        ).length;
        if (count >= 20) return { ok: false as const, reason: "limit" as const };
        set({ keys: [key, ...get().keys] });
        return { ok: true as const };
      },
      updateKey: (id, patch) =>
        set({
          keys: get().keys.map((k) => (k.id === id ? { ...k, ...patch } : k)),
        }),
      removeKey: (id) => set({ keys: get().keys.filter((k) => k.id !== id) }),
      touchKey: (id) =>
        set({
          keys: get().keys.map((k) =>
            k.id === id ? { ...k, lastUsedAt: Date.now() } : k,
          ),
        }),
      addUsage: (tokensIn, tokensOut) => {
        const u = get().usage;
        const daily = Array.isArray(u.daily) ? [...u.daily] : [];
        const day = todayKey();
        const tokens = tokensIn + tokensOut;
        const idx = daily.findIndex((d) => d.day === day);
        if (idx >= 0) {
          const current = daily[idx];
          daily[idx] = {
            day,
            requests: current.requests + 1,
            tokens: current.tokens + tokens,
          };
        } else {
          daily.push({ day, requests: 1, tokens });
        }
        set({
          usage: {
            requests: u.requests + 1,
            tokensIn: u.tokensIn + tokensIn,
            tokensOut: u.tokensOut + tokensOut,
            daily: daily.slice(-14),
          },
        });
      },
    }),
    {
      name: "lumen-studio-v1",
      partialize: (s) => ({
        locale: s.locale,
        regionId: s.regionId,
        workspaces: s.workspaces,
        keys: s.keys,
        usage: s.usage,
      }),
      onRehydrateStorage: () => () => {
        useStudio.getState().setHydrated(true);
      },
    },
  ),
);

export function useVisibleKeys(kind: KeyKind) {
  const keys = useStudio((s) => s.keys);
  const regionId = useStudio((s) => s.regionId);
  const query = useStudio((s) => s.query);
  const hydrated = useStudio((s) => s.hydrated);
  if (!hydrated) return [];
  const q = query.trim().toLowerCase();
  const now = Date.now();
  return keys.filter((k) => {
    if (k.regionId !== regionId) return false;
    if (k.kind !== kind) return false;
    if (k.kind === "temporary" && k.expiresAt && k.expiresAt < now) {
      /* still listed, marked expired in UI */
    }
    if (!q) return true;
    return (
      k.secret.toLowerCase().includes(q) ||
      k.description.toLowerCase().includes(q) ||
      k.id.toLowerCase().includes(q)
    );
  });
}

export function useHydrated() {
  return useStudio((s) => s.hydrated);
}
