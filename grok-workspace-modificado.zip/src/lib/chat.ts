import { createServerFn } from "@tanstack/react-start";

type ChatInput = {
  key: string;
  model: string;
  messages: { role: string; content: string }[];
};

export const completeChat = createServerFn({ method: "POST" })
  .validator((input: ChatInput) => input)
  .handler(async ({ data }) => {
    const { complete } = await import("./complete.server");
    return complete(data);
  });
