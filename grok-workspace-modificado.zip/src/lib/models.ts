export const REGIONS = [
  { id: "sa-east-1", city: "São Paulo", cityEn: "São Paulo", code: "sa-east-1" },
  { id: "eu-west-1", city: "Lisboa", cityEn: "Lisbon", code: "eu-west-1" },
  { id: "us-east-1", city: "Virgínia", cityEn: "Virginia", code: "us-east-1" },
] as const;

export type ModelModality = "text" | "vision" | "image" | "embed";

export type CatalogModel = {
  id: string;
  name: string;
  family: string;
  modality: ModelModality;
  blurbPt: string;
  blurbEn: string;
  context: string;
  chat: boolean;
  rpm: number;
};

export const MODELS: CatalogModel[] = [
  {
    id: "lumen-max",
    name: "Lúmen Max",
    family: "Flagship",
    modality: "text",
    blurbPt: "Raciocínio profundo para código, pesquisa e tarefas longas.",
    blurbEn: "Deep reasoning for code, research, and long-horizon work.",
    context: "128K",
    chat: true,
    rpm: 60,
  },
  {
    id: "lumen-plus",
    name: "Lúmen Plus",
    family: "Flagship",
    modality: "text",
    blurbPt: "Equilíbrio entre qualidade, custo e velocidade no dia a dia.",
    blurbEn: "Balanced quality, cost, and speed for everyday work.",
    context: "128K",
    chat: true,
    rpm: 120,
  },
  {
    id: "lumen-flash",
    name: "Lúmen Flash",
    family: "Fast",
    modality: "text",
    blurbPt: "Respostas rápidas para classificação, resumo e chat simples.",
    blurbEn: "Fast replies for classification, summaries, and light chat.",
    context: "64K",
    chat: true,
    rpm: 240,
  },
  {
    id: "lumen-vision",
    name: "Lúmen Vision",
    family: "Multimodal",
    modality: "vision",
    blurbPt: "Entende imagens e texto no mesmo turno — gráficos, UI, documentos.",
    blurbEn: "Reads images and text together — charts, UI, documents.",
    context: "64K",
    chat: true,
    rpm: 60,
  },
  {
    id: "lumen-image",
    name: "Lúmen Image",
    family: "Media",
    modality: "image",
    blurbPt: "Geração de imagens a partir de instruções detalhadas.",
    blurbEn: "Image generation from detailed instructions.",
    context: "—",
    chat: false,
    rpm: 20,
  },
  {
    id: "lumen-embed",
    name: "Lúmen Embed",
    family: "Retrieval",
    modality: "embed",
    blurbPt: "Embeddings densos para busca semântica e RAG.",
    blurbEn: "Dense embeddings for semantic search and RAG.",
    context: "8K",
    chat: false,
    rpm: 300,
  },
];

export const CHAT_MODELS = MODELS.filter((m) => m.chat);

export const MODEL_RUNTIME: Record<string, { xai: string; maxTokens: number }> = {
  "lumen-max": { xai: process.env.XAI_MODEL_MAX || "grok-4.5", maxTokens: 2048 },
  "lumen-plus": { xai: process.env.XAI_MODEL_PLUS || process.env.XAI_MODEL_MAX || "grok-4.5", maxTokens: 1024 },
  "lumen-flash": { xai: process.env.XAI_MODEL_FLASH || process.env.XAI_MODEL_MAX || "grok-4.5", maxTokens: 512 },
  "lumen-vision": { xai: process.env.XAI_MODEL_VISION || process.env.XAI_MODEL_MAX || "grok-4.5", maxTokens: 1024 },
};

export const FREE_TOKEN_QUOTA = Math.max(0, Number(process.env.FREE_TOKEN_QUOTA ?? 0));

export function apiHost(origin: string) {
  return `${origin.replace(/\/$/, "")}/api/v1`;
}

export function regionLabel(id: string, locale: "pt" | "en") {
  const region = REGIONS.find((r) => r.id === id);
  if (!region) return id;
  return `${locale === "pt" ? region.city : region.cityEn} (${region.code})`;
}
