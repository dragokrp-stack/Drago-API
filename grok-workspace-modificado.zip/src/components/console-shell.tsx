import { useEffect, useState } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import {
  BookOpen,
  FlaskConical,
  KeyRound,
  LayoutGrid,
  Menu,
  Search,
  Sparkles,
  X,
  Gauge,
  Globe,
} from "lucide-react";
import { LogoMark } from "@/components/logo";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { NativeSelect } from "@/components/ui/input";
import { t } from "@/lib/i18n";
import { REGIONS } from "@/lib/models";
import { useStudio } from "@/lib/store";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/playground", key: "navPlayground" as const, icon: FlaskConical },
  { to: "/models", key: "navModels" as const, icon: Sparkles },
  { to: "/", key: "navApiKey" as const, icon: KeyRound },
  { to: "/usage", key: "navUsage" as const, icon: Gauge },
  { to: "/workspaces", key: "navWorkspaces" as const, icon: LayoutGrid },
  { to: "/docs", key: "navDocs" as const, icon: BookOpen },
];

export function ConsoleShell({
  title,
  hint,
  children,
  actions,
}: {
  title: string;
  hint?: string;
  children: React.ReactNode;
  actions?: React.ReactNode;
}) {
  const locale = useStudio((s) => s.locale);
  const regionId = useStudio((s) => s.regionId);
  const query = useStudio((s) => s.query);
  const copy = t(locale);
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [open, setOpen] = useState(false);

  useEffect(() => {
    document.documentElement.lang = locale === "pt" ? "pt-BR" : "en";
  }, [locale]);

  useEffect(() => {
    const finish = () => useStudio.getState().setHydrated(true);
    const unsub = useStudio.persist.onFinishHydration(finish);
    if (useStudio.persist.hasHydrated()) finish();
    return unsub;
  }, []);

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <header className="sticky top-0 z-40 flex h-14 items-center gap-3 border-b border-border bg-header px-3 sm:px-4">
        <Button
          variant="ghost"
          size="iconSm"
          className="lg:hidden"
          aria-label={open ? copy.closeMenu : copy.openMenu}
          onClick={() => setOpen((v) => !v)}
        >
          {open ? <X /> : <Menu />}
        </Button>
        <Link to="/" className="flex min-w-0 items-center gap-2 text-fg">
          <LogoMark className="size-7 shrink-0 text-primary" />
          <span className="truncate text-sm font-semibold tracking-tight">{copy.product}</span>
          <span className="hidden text-xs text-subtle xl:inline">{copy.tagline}</span>
        </Link>
        <div className="relative mx-auto hidden min-w-0 max-w-md flex-1 md:block">
          <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-subtle" />
          <Input
            value={query}
            onChange={(e) => useStudio.getState().setQuery(e.target.value)}
            placeholder={copy.search}
            className="h-9 pl-9"
            aria-label={copy.search}
          />
        </div>
        <div className="ml-auto flex items-center gap-2">
          <label className="hidden items-center gap-2 text-xs text-muted sm:flex">
            <Globe className="size-3.5" />
            <NativeSelect
              className="h-9 w-40 text-xs"
              value={regionId}
              onChange={(e) => useStudio.getState().setRegion(e.target.value)}
              aria-label={copy.region}
            >
              {REGIONS.map((r) => (
                <option key={r.id} value={r.id}>
                  {locale === "pt" ? r.city : r.cityEn} ({r.code})
                </option>
              ))}
            </NativeSelect>
          </label>
          <NativeSelect
            className="h-9 w-16 text-xs"
            value={locale}
            onChange={(e) => useStudio.getState().setLocale(e.target.value === "en" ? "en" : "pt")}
            aria-label="Language"
          >
            <option value="pt">PT</option>
            <option value="en">EN</option>
          </NativeSelect>
          <div className="hidden items-center gap-2 rounded-full bg-bg px-2 py-1 sm:flex">
            <span className="size-6 rounded-full bg-primary text-center text-xs leading-6 font-semibold text-primary-fg">
              LS
            </span>
            <span className="pr-1 text-xs text-muted">{copy.account}</span>
            <Badge tone="accent">{copy.free}</Badge>
          </div>
        </div>
      </header>

      <div className="flex">
        {open ? (
          <button
            type="button"
            className="fixed inset-0 z-30 bg-fg/30 lg:hidden"
            aria-label={copy.closeMenu}
            onClick={() => setOpen(false)}
          />
        ) : null}
        <aside
          className={cn(
            "fixed top-14 bottom-0 z-30 w-60 overflow-y-auto border-r border-border bg-sidebar p-3 transition-transform duration-(--motion-fast) ease-(--ease-out) lg:sticky lg:h-[calc(100dvh-3.5rem)] lg:translate-x-0",
            open ? "translate-x-0" : "-translate-x-full lg:translate-x-0",
          )}
        >
          <p className="px-2 pb-2 text-xs font-semibold tracking-wide text-subtle uppercase">
            {copy.navDashboard}
          </p>
          <nav className="flex flex-col gap-0.5">
            {NAV.map((item) => {
              const active =
                item.to === "/"
                  ? pathname === "/"
                  : pathname === item.to || pathname.startsWith(`${item.to}/`);
              const Icon = item.icon;
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  onClick={() => setOpen(false)}
                  className={cn(
                    "flex h-11 items-center gap-2 rounded-md px-2.5 text-sm transition-colors duration-(--motion-quick)",
                    active
                      ? "bg-nav-active font-medium text-primary"
                      : "text-muted hover:bg-bg hover:text-fg",
                  )}
                >
                  <Icon className="size-4" />
                  {copy[item.key]}
                </Link>
              );
            })}
          </nav>
          <div className="mt-6 space-y-2 px-2 lg:hidden">
            <p className="text-xs font-medium text-muted">{copy.region}</p>
            <NativeSelect
              value={regionId}
              onChange={(e) => useStudio.getState().setRegion(e.target.value)}
              aria-label={copy.region}
            >
              {REGIONS.map((r) => (
                <option key={r.id} value={r.id}>
                  {locale === "pt" ? r.city : r.cityEn} ({r.code})
                </option>
              ))}
            </NativeSelect>
          </div>
          <p className="mt-6 px-2 text-xs leading-5 text-subtle">{copy.allRegions}</p>
        </aside>

        <main className="min-w-0 flex-1 px-4 py-5 sm:px-6 lg:px-8">
          <p className="mb-3 text-xs text-subtle">
            {copy.breadcrumbDash}
            <span className="mx-1.5">/</span>
            <span className="text-muted">{title}</span>
          </p>
          <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <h1 className="text-xl font-semibold tracking-tight">{title}</h1>
              {hint ? <p className="mt-1 max-w-2xl text-sm text-muted">{hint}</p> : null}
            </div>
            {actions ? <div className="flex flex-wrap gap-2">{actions}</div> : null}
          </div>
          {children}
        </main>
      </div>
    </div>
  );
}
