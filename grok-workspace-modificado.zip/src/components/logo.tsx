export function LogoMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" className={className} aria-hidden="true">
      <rect width="32" height="32" rx="7" fill="currentColor" />
      <path
        d="M9 8h5.2c4.4 0 7.4 2.6 7.4 6.6 0 4.1-3.1 6.7-7.6 6.7H13.2V24H9V8zm4.2 3.1v5.2h1.1c2.2 0 3.5-1.1 3.5-2.6 0-1.5-1.2-2.6-3.4-2.6H13.2z"
        fill="#fff"
      />
    </svg>
  );
}
