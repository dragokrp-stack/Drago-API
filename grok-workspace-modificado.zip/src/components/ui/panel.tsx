import { cn } from "@/lib/utils";

export function Panel({
  className,
  children,
}: {
  className?: string;
  children?: React.ReactNode;
}) {
  return (
    <div className={cn("rounded-lg bg-surface shadow-[var(--shadow-border)]", className)}>
      {children}
    </div>
  );
}
