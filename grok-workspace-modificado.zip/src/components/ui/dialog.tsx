import * as DialogPrimitive from "@radix-ui/react-dialog";
import { X } from "lucide-react";
import { cn } from "@/lib/utils";

export const Dialog = DialogPrimitive.Root;
export const DialogTrigger = DialogPrimitive.Trigger;
export const DialogClose = DialogPrimitive.Close;

export function DialogContent({
  className,
  children,
  title,
}: {
  className?: string;
  children: React.ReactNode;
  title: string;
}) {
  return (
    <DialogPrimitive.Portal>
      <DialogPrimitive.Overlay className="fixed inset-0 z-50 bg-fg/40 data-[state=open]:animate-[fade-in_var(--motion-fast)_var(--ease-out)] data-[state=closed]:animate-[fade-out_var(--motion-quick)_var(--ease-out)]" />
      <DialogPrimitive.Content
        className={cn(
          "fixed top-1/2 left-1/2 z-50 w-[min(100%-1.5rem,34rem)] -translate-x-1/2 -translate-y-1/2 rounded-xl bg-surface p-5 shadow-[var(--shadow-modal)]",
          "data-[state=open]:animate-[modal-in_var(--motion-fast)_var(--ease-out)] data-[state=closed]:animate-[modal-out_var(--motion-quick)_var(--ease-out)]",
          "max-h-[min(90vh,40rem)] overflow-y-auto",
          className,
        )}
      >
        <div className="mb-4 flex items-start justify-between gap-3">
          <DialogPrimitive.Title className="text-base font-semibold tracking-tight text-fg text-balance">
            {title}
          </DialogPrimitive.Title>
          <DialogPrimitive.Close className="inline-flex size-8 items-center justify-center rounded-md text-muted hover:bg-bg hover:text-fg">
            <X className="size-4" />
          </DialogPrimitive.Close>
        </div>
        {children}
      </DialogPrimitive.Content>
    </DialogPrimitive.Portal>
  );
}
