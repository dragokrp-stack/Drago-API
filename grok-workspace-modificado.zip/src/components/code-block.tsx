import { useState } from "react";
import { Check, Copy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { copyText } from "@/lib/utils";
import { cn } from "@/lib/utils";

export function CodeBlock({
  code,
  label,
}: {
  code: string;
  label?: string;
}) {
  const [done, setDone] = useState(false);

  return (
    <div className="overflow-hidden rounded-lg bg-code shadow-[var(--shadow-border)]">
      <div className="flex items-center justify-between border-b border-border px-3 py-1.5">
        <span className="text-xs text-subtle">{label}</span>
        <Button
          variant="ghost"
          size="iconSm"
          aria-label="Copy"
          onClick={async () => {
            await copyText(code);
            setDone(true);
            setTimeout(() => setDone(false), 1500);
          }}
        >
          {done ? <Check /> : <Copy />}
        </Button>
      </div>
      <pre className={cn("overflow-x-auto p-4 font-mono text-xs leading-6 text-fg")}>
        <code>{code}</code>
      </pre>
    </div>
  );
}
