import { useState } from "react";
import { toast } from "sonner";
import {
  Copy,
  Download,
  KeyRound,
  MoreHorizontal,
  Pencil,
  Plus,
  Trash2,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown";
import { Input, NativeSelect, Textarea } from "@/components/ui/input";
import { Panel } from "@/components/ui/panel";
import { useOrigin } from "@/hooks/use-origin";
import { issueApiKey } from "@/lib/issue-key";
import { t } from "@/lib/i18n";
import { MODELS, apiHost } from "@/lib/models";
import { useHydrated, useStudio, useVisibleKeys } from "@/lib/store";
import type { AccessScope, ApiKeyRecord, KeyKind } from "@/lib/types";
import { copyText, downloadText, formatDate, maskKey, parseIpList } from "@/lib/utils";
import { cn } from "@/lib/utils";

type FormState = {
  workspaceId: string;
  description: string;
  access: AccessScope;
  ipWhitelist: string;
  allowedModels: string[];
};

const emptyForm = (workspaceId: string): FormState => ({
  workspaceId,
  description: "",
  access: "all",
  ipWhitelist: "0.0.0.0/0",
  allowedModels: MODELS.filter((m) => m.chat).map((m) => m.id),
});

export function KeysManager() {
  const locale = useStudio((s) => s.locale);
  const copy = t(locale);
  const regionId = useStudio((s) => s.regionId);
  const workspaces = useStudio((s) => s.workspaces);
  const query = useStudio((s) => s.query);
  const hydrated = useHydrated();
  const [tab, setTab] = useState<KeyKind>("standard");
  const keys = useVisibleKeys(tab);
  const [createOpen, setCreateOpen] = useState(false);
  const [form, setForm] = useState<FormState>(emptyForm("ws-default"));
  const [busy, setBusy] = useState(false);
  const [reveal, setReveal] = useState<ApiKeyRecord | null>(null);
  const [edit, setEdit] = useState<ApiKeyRecord | null>(null);
  const [confirm, setConfirm] = useState<
    | { type: "delete"; key: ApiKeyRecord }
    | { type: "reset"; key: ApiKeyRecord }
    | null
  >(null);

  const origin = useOrigin();
  const host = origin ? apiHost(origin) : "";

  function openCreate() {
    setForm(emptyForm(workspaces[0]?.id ?? "ws-default"));
    setCreateOpen(true);
  }

  async function submitCreate() {
    setBusy(true);
    try {
      const issued = await issueApiKey();
      const rec: ApiKeyRecord = {
        id: issued.id,
        secret: issued.key,
        kind: tab,
        description: form.description.trim().slice(0, 200),
        workspaceId: form.workspaceId,
        regionId,
        status: "enabled",
        access: form.access,
        ipWhitelist:
          form.access === "custom"
            ? parseIpList(form.ipWhitelist).join(", ") || "0.0.0.0/0"
            : "0.0.0.0/0",
        allowedModels: form.access === "custom" ? form.allowedModels : [],
        createdAt: issued.issuedAt,
        expiresAt: tab === "temporary" ? issued.issuedAt + 24 * 60 * 60 * 1000 : null,
        lastUsedAt: null,
      };
      const result = useStudio.getState().addKey(rec);
      if (!result.ok) {
        toast.error(copy.limit);
        return;
      }
      setCreateOpen(false);
      setReveal(rec);
    } catch {
      toast.error(copy.errIssue);
    } finally {
      setBusy(false);
    }
  }

  async function submitReset(key: ApiKeyRecord) {
    setBusy(true);
    try {
      const issued = await issueApiKey();
      const next: ApiKeyRecord = {
        ...key,
        id: issued.id,
        secret: issued.key,
        createdAt: issued.issuedAt,
        expiresAt: key.kind === "temporary" ? issued.issuedAt + 24 * 60 * 60 * 1000 : key.expiresAt,
        lastUsedAt: null,
      };
      useStudio.getState().removeKey(key.id);
      const result = useStudio.getState().addKey(next);
      if (!result.ok) {
        useStudio.getState().addKey(key);
        toast.error(copy.limit);
        return;
      }
      setConfirm(null);
      setReveal(next);
    } catch {
      toast.error(copy.errIssue);
    } finally {
      setBusy(false);
    }
  }

  function saveEdit() {
    if (!edit) return;
    useStudio.getState().updateKey(edit.id, {
      description: form.description.trim().slice(0, 200),
      workspaceId: form.workspaceId,
      access: form.access,
      ipWhitelist:
        form.access === "custom"
          ? parseIpList(form.ipWhitelist).join(", ") || "0.0.0.0/0"
          : "0.0.0.0/0",
      allowedModels: form.access === "custom" ? form.allowedModels : [],
    });
    setEdit(null);
  }

  async function onCopy(secret: string) {
    await copyText(secret);
    toast.success(copy.copied);
  }

  const filteredEmpty = hydrated && keys.length === 0 && query.trim().length > 0;

  return (
    <div className="space-y-4">
      <div className="flex items-start gap-3 rounded-lg bg-primary-soft px-4 py-3 text-sm text-fg">
        <span className="mt-0.5 inline-block size-2 shrink-0 rounded-full bg-success" />
        <p>{copy.banner}</p>
      </div>

      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex gap-1 overflow-x-auto border-b border-border">
          {(["standard", "temporary"] as const).map((kind) => (
            <button
              key={kind}
              type="button"
              onClick={() => setTab(kind)}
              className={cn(
                "-mb-px h-11 shrink-0 px-3 text-sm transition-colors duration-(--motion-quick)",
                tab === kind
                  ? "border-b-2 border-primary font-medium text-primary"
                  : "text-muted hover:text-fg",
              )}
            >
              {kind === "standard" ? copy.tabStandard : copy.tabTemp}
            </button>
          ))}
        </div>
        <Button size="lg" className="w-full sm:w-auto" onClick={openCreate}>
          <Plus />
          {tab === "standard" ? copy.createKey : copy.createTemp}
        </Button>
      </div>

      {!hydrated ? (
        <Panel className="space-y-2 p-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="h-12 animate-pulse rounded-md bg-bg" />
          ))}
        </Panel>
      ) : keys.length === 0 ? (
        <Panel className="flex flex-col items-center px-6 py-14 text-center">
          <span className="mb-3 inline-flex size-12 items-center justify-center rounded-xl bg-primary-soft text-primary">
            <KeyRound className="size-6" />
          </span>
          <h2 className="text-base font-semibold">
            {filteredEmpty ? copy.noMatch : copy.emptyTitle}
          </h2>
          <p className="mt-1 max-w-md text-sm text-muted">
            {filteredEmpty ? copy.filter : copy.emptyBody}
          </p>
          {!filteredEmpty ? (
            <Button className="mt-5" onClick={openCreate}>
              <Plus />
              {tab === "standard" ? copy.createKey : copy.createTemp}
            </Button>
          ) : null}
        </Panel>
      ) : (
        <>
          <div className="hidden overflow-x-auto md:block">
            <Panel>
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="border-b border-border text-xs text-subtle">
                    <th className="px-4 py-3 font-medium">{copy.colKey}</th>
                    <th className="px-4 py-3 font-medium">{copy.colDesc}</th>
                    <th className="px-4 py-3 font-medium">{copy.colWorkspace}</th>
                    <th className="px-4 py-3 font-medium">{copy.colCreated}</th>
                    {tab === "temporary" ? (
                      <th className="px-4 py-3 font-medium">{copy.colExpires}</th>
                    ) : (
                      <th className="px-4 py-3 font-medium">{copy.lastUsed}</th>
                    )}
                    <th className="px-4 py-3 font-medium">{copy.colStatus}</th>
                    <th className="px-4 py-3 font-medium">{copy.colActions}</th>
                  </tr>
                </thead>
                <tbody>
                  {keys.map((k) => (
                    <KeyRow
                      key={k.id}
                      rec={k}
                      locale={locale}
                      onCopy={() => onCopy(k.secret)}
                      onEdit={() => {
                        setForm({
                          workspaceId: k.workspaceId,
                          description: k.description,
                          access: k.access,
                          ipWhitelist: k.ipWhitelist || "0.0.0.0/0",
                          allowedModels:
                            k.allowedModels.length > 0
                              ? k.allowedModels
                              : MODELS.filter((m) => m.chat).map((m) => m.id),
                        });
                        setEdit(k);
                      }}
                      onDelete={() => setConfirm({ type: "delete", key: k })}
                      onReset={() => setConfirm({ type: "reset", key: k })}
                    />
                  ))}
                </tbody>
              </table>
            </Panel>
          </div>
          <div className="space-y-3 md:hidden">
            {keys.map((k) => (
              <KeyCard
                key={k.id}
                rec={k}
                locale={locale}
                onCopy={() => onCopy(k.secret)}
                onEdit={() => {
                  setForm({
                    workspaceId: k.workspaceId,
                    description: k.description,
                    access: k.access,
                    ipWhitelist: k.ipWhitelist || "0.0.0.0/0",
                    allowedModels:
                      k.allowedModels.length > 0
                        ? k.allowedModels
                        : MODELS.filter((m) => m.chat).map((m) => m.id),
                  });
                  setEdit(k);
                }}
                onDelete={() => setConfirm({ type: "delete", key: k })}
                onReset={() => setConfirm({ type: "reset", key: k })}
              />
            ))}
          </div>
        </>
      )}

      <p className="text-xs text-subtle">{copy.limit}</p>

      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent title={tab === "temporary" ? copy.createTempTitle : copy.createTitle}>
          {tab === "temporary" ? (
            <p className="mb-4 text-sm text-muted">{copy.createTempHint}</p>
          ) : null}
          <KeyFormFields form={form} setForm={setForm} />
          <div className="mt-5 flex justify-end gap-2">
            <Button variant="outline" onClick={() => setCreateOpen(false)}>
              {copy.cancel}
            </Button>
            <Button onClick={submitCreate} disabled={busy}>
              {busy ? copy.creating : copy.ok}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={Boolean(edit)} onOpenChange={(o) => !o && setEdit(null)}>
        <DialogContent title={copy.editTitle}>
          <KeyFormFields form={form} setForm={setForm} />
          {edit ? (
            <p className="mt-3 text-xs text-subtle">{copy.enabledHint}</p>
          ) : null}
          <div className="mt-5 flex justify-end gap-2">
            <Button variant="outline" onClick={() => setEdit(null)}>
              {copy.cancel}
            </Button>
            <Button onClick={saveEdit}>{copy.save}</Button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={Boolean(reveal)} onOpenChange={(o) => !o && setReveal(null)}>
        <DialogContent title={copy.revealTitle}>
          {reveal ? (
            <RevealBody rec={reveal} host={host} onCopy={onCopy} />
          ) : null}
        </DialogContent>
      </Dialog>

      <Dialog open={Boolean(confirm)} onOpenChange={(o) => !o && setConfirm(null)}>
        <DialogContent
          title={confirm?.type === "reset" ? copy.resetTitle : copy.deleteTitle}
        >
          <p className="text-sm text-muted">
            {confirm?.type === "reset" ? copy.resetBody : copy.deleteBody}
          </p>
          <div className="mt-5 flex justify-end gap-2">
            <Button variant="outline" onClick={() => setConfirm(null)}>
              {copy.cancel}
            </Button>
            {confirm?.type === "delete" ? (
              <Button
                variant="danger"
                onClick={() => {
                  if (confirm) useStudio.getState().removeKey(confirm.key.id);
                  setConfirm(null);
                }}
              >
                {copy.del}
              </Button>
            ) : (
              <Button
                variant="danger"
                disabled={busy}
                onClick={() => confirm && submitReset(confirm.key)}
              >
                {busy ? copy.creating : copy.resetNow}
              </Button>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function KeyFormFields({
  form,
  setForm,
}: {
  form: FormState;
  setForm: (next: FormState) => void;
}) {
  const locale = useStudio((s) => s.locale);
  const copy = t(locale);
  const workspaces = useStudio((s) => s.workspaces);

  return (
    <div className="space-y-4">
      <label className="block space-y-1.5">
        <span className="text-xs font-medium text-muted">{copy.owner}</span>
        <Input value={copy.ownerValue} disabled />
      </label>
      <label className="block space-y-1.5">
        <span className="text-xs font-medium text-muted">{copy.workspace}</span>
        <NativeSelect
          value={form.workspaceId}
          onChange={(e) => setForm({ ...form, workspaceId: e.target.value })}
        >
          {workspaces.map((w) => (
            <option key={w.id} value={w.id}>
              {w.id === "ws-default" ? copy.wsDefault : w.name}
            </option>
          ))}
        </NativeSelect>
      </label>
      <label className="block space-y-1.5">
        <span className="flex justify-between text-xs font-medium text-muted">
          <span>{copy.description}</span>
          <span>
            {form.description.length}/200 · {copy.chars}
          </span>
        </span>
        <Textarea
          maxLength={200}
          value={form.description}
          placeholder={copy.descriptionPh}
          onChange={(e) => setForm({ ...form, description: e.target.value })}
        />
      </label>
      <fieldset className="space-y-2">
        <legend className="text-xs font-medium text-muted">{copy.access}</legend>
        <div className="grid grid-cols-2 gap-2">
          {(["all", "custom"] as const).map((scope) => (
            <button
              key={scope}
              type="button"
              onClick={() => setForm({ ...form, access: scope })}
              className={cn(
                "h-11 rounded-md text-sm shadow-[var(--shadow-border)] transition-colors duration-(--motion-quick)",
                form.access === scope
                  ? "bg-primary-soft font-medium text-primary"
                  : "bg-surface text-muted hover:text-fg",
              )}
            >
              {scope === "all" ? copy.accessAll : copy.accessCustom}
            </button>
          ))}
        </div>
      </fieldset>
      {form.access === "custom" ? (
        <>
          <label className="block space-y-1.5">
            <span className="text-xs font-medium text-muted">{copy.ipList}</span>
            <Input
              value={form.ipWhitelist}
              placeholder={copy.ipPh}
              onChange={(e) => setForm({ ...form, ipWhitelist: e.target.value })}
            />
          </label>
          <fieldset className="space-y-2">
            <legend className="text-xs font-medium text-muted">{copy.modelScope}</legend>
            <div className="grid gap-1 sm:grid-cols-2">
              {MODELS.map((m) => {
                const checked = form.allowedModels.includes(m.id);
                return (
                  <label
                    key={m.id}
                    className="flex min-h-11 items-center gap-2 rounded-md px-2 text-sm hover:bg-bg"
                  >
                    <input
                      type="checkbox"
                      className="size-4 accent-primary"
                      checked={checked}
                      onChange={() => {
                        const next = checked
                          ? form.allowedModels.filter((id) => id !== m.id)
                          : [...form.allowedModels, m.id];
                        setForm({ ...form, allowedModels: next });
                      }}
                    />
                    {m.name}
                  </label>
                );
              })}
            </div>
          </fieldset>
        </>
      ) : null}
    </div>
  );
}

function statusOf(rec: ApiKeyRecord) {
  if (rec.expiresAt && rec.expiresAt < Date.now()) return "expired" as const;
  return rec.status;
}

function KeyRow({
  rec,
  locale,
  onCopy,
  onEdit,
  onDelete,
  onReset,
}: {
  rec: ApiKeyRecord;
  locale: "pt" | "en";
  onCopy: () => void;
  onEdit: () => void;
  onDelete: () => void;
  onReset: () => void;
}) {
  const copy = t(locale);
  const workspaces = useStudio((s) => s.workspaces);
  const ws = workspaces.find((w) => w.id === rec.workspaceId);
  const status = statusOf(rec);
  return (
    <tr className="border-b border-border last:border-0 hover:bg-bg">
      <td className="px-4 py-3 font-mono text-xs">{maskKey(rec.secret)}</td>
      <td className="max-w-40 truncate px-4 py-3 text-muted">{rec.description || copy.never}</td>
      <td className="px-4 py-3 text-muted">
        {ws?.id === "ws-default" ? copy.wsDefault : (ws?.name ?? rec.workspaceId)}
      </td>
      <td className="px-4 py-3 text-muted tabular-nums">{formatDate(rec.createdAt, locale)}</td>
      <td className="px-4 py-3 text-muted tabular-nums">
        {rec.kind === "temporary"
          ? rec.expiresAt
            ? formatDate(rec.expiresAt, locale)
            : copy.never
          : rec.lastUsedAt
            ? formatDate(rec.lastUsedAt, locale)
            : copy.never}
      </td>
      <td className="px-4 py-3">
        <Badge
          tone={status === "enabled" ? "success" : status === "expired" ? "warn" : "neutral"}
        >
          {status === "enabled" ? copy.enabled : status === "expired" ? copy.expired : copy.disabled}
        </Badge>
      </td>
      <td className="px-4 py-3">
        <RowActions
          rec={rec}
          onCopy={onCopy}
          onEdit={onEdit}
          onDelete={onDelete}
          onReset={onReset}
        />
      </td>
    </tr>
  );
}

function KeyCard({
  rec,
  locale,
  onCopy,
  onEdit,
  onDelete,
  onReset,
}: {
  rec: ApiKeyRecord;
  locale: "pt" | "en";
  onCopy: () => void;
  onEdit: () => void;
  onDelete: () => void;
  onReset: () => void;
}) {
  const copy = t(locale);
  const workspaces = useStudio((s) => s.workspaces);
  const ws = workspaces.find((w) => w.id === rec.workspaceId);
  const status = statusOf(rec);
  return (
    <Panel className="p-4">
      <div className="flex items-start justify-between gap-2">
        <p className="font-mono text-xs break-all">{maskKey(rec.secret)}</p>
        <Badge
          tone={status === "enabled" ? "success" : status === "expired" ? "warn" : "neutral"}
        >
          {status === "enabled" ? copy.enabled : status === "expired" ? copy.expired : copy.disabled}
        </Badge>
      </div>
      <p className="mt-2 text-sm text-muted">{rec.description || copy.never}</p>
      <p className="mt-1 text-xs text-subtle">
        {ws?.id === "ws-default" ? copy.wsDefault : (ws?.name ?? rec.workspaceId)} ·{" "}
        {formatDate(rec.createdAt, locale)}
      </p>
      <div className="mt-3">
        <RowActions
          rec={rec}
          onCopy={onCopy}
          onEdit={onEdit}
          onDelete={onDelete}
          onReset={onReset}
        />
      </div>
    </Panel>
  );
}

function RowActions({
  rec,
  onCopy,
  onEdit,
  onDelete,
  onReset,
}: {
  rec: ApiKeyRecord;
  onCopy: () => void;
  onEdit: () => void;
  onDelete: () => void;
  onReset: () => void;
}) {
  const locale = useStudio((s) => s.locale);
  const copy = t(locale);
  const expired = statusOf(rec) === "expired";
  return (
    <div className="flex items-center gap-1">
      <Button variant="ghost" size="icon" aria-label={copy.copy} onClick={onCopy}>
        <Copy />
      </Button>
      <Button variant="ghost" size="icon" aria-label={copy.edit} onClick={onEdit}>
        <Pencil />
      </Button>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" size="icon" aria-label={copy.more}>
            <MoreHorizontal />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent>
          <DropdownMenuItem
            disabled={expired}
            onSelect={() =>
              useStudio.getState().updateKey(rec.id, {
                status: rec.status === "enabled" ? "disabled" : "enabled",
              })
            }
          >
            {rec.status === "enabled" ? copy.disable : copy.enable}
          </DropdownMenuItem>
          <DropdownMenuItem onSelect={onReset}>{copy.reset}</DropdownMenuItem>
          <DropdownMenuItem tone="danger" onSelect={onDelete}>
            <Trash2 className="size-4" />
            {copy.del}
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}

function RevealBody({
  rec,
  host,
  onCopy,
}: {
  rec: ApiKeyRecord;
  host: string;
  onCopy: (secret: string) => void;
}) {
  const locale = useStudio((s) => s.locale);
  const copy = t(locale);
  const hours = rec.expiresAt
    ? Math.max(0, Math.round((rec.expiresAt - Date.now()) / 36e5))
    : null;

  return (
    <div className="space-y-4">
      <p className="rounded-md bg-warn-soft px-3 py-2 text-sm text-warn">{copy.revealWarn}</p>
      <label className="block space-y-1.5">
        <span className="text-xs font-medium text-muted">{copy.colKey}</span>
        <div className="flex gap-2">
          <Input readOnly value={rec.secret} className="font-mono text-xs" />
          <Button variant="outline" aria-label={copy.copy} onClick={() => onCopy(rec.secret)}>
            <Copy />
          </Button>
        </div>
      </label>
      <label className="block space-y-1.5">
        <span className="text-xs font-medium text-muted">{copy.apiHost}</span>
        <div className="flex gap-2">
          <Input readOnly value={host} className="font-mono text-xs" />
          <Button
            variant="outline"
            aria-label={copy.copyHost}
            onClick={() => host && onCopy(host)}
          >
            <Copy />
          </Button>
        </div>
      </label>
      {hours !== null ? (
        <p className="text-xs text-muted">
          {hours} {copy.hoursLeft}
        </p>
      ) : (
        <p className="text-xs text-muted">{copy.forever}</p>
      )}
      <div className="flex flex-wrap justify-end gap-2">
        <Button
          variant="outline"
          onClick={() =>
            downloadText(
              `${copy.keyFile}.txt`,
              `Lúmen Studio API Key\nRegion: ${rec.regionId}\nHost: ${host}\nKey: ${rec.secret}\n`,
            )
          }
        >
          <Download />
          {copy.download}
        </Button>
        <Button onClick={() => onCopy(rec.secret)}>{copy.copy}</Button>
      </div>
    </div>
  );
}
